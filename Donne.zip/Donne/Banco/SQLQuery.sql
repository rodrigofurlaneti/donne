USE [master]
GO

/****** Object:  Database [rodrigofurlaneti_donne]    Script Date: 19/10/2021 09:47:52 ******/
CREATE DATABASE [rodrigofurlaneti_donne]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'rodrigofurlaneti_donne', FILENAME = N'F:\MSSQL14.MSSQLSERVER\MSSQL\DATA\\rodrigofurlaneti_donne.mdf' , SIZE = 10240KB , MAXSIZE = 102400KB , FILEGROWTH = 1024KB )
 LOG ON 
( NAME = N'rodrigofurlaneti_donne_log', FILENAME = N'F:\MSSQL14.MSSQLSERVER\MSSQL\DATA\rodrigofurlaneti_donne_log.ldf' , SIZE = 73728KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
GO

IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [rodrigofurlaneti_donne].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO

ALTER DATABASE [rodrigofurlaneti_donne] SET ANSI_NULL_DEFAULT OFF 
GO

ALTER DATABASE [rodrigofurlaneti_donne] SET ANSI_NULLS OFF 
GO

ALTER DATABASE [rodrigofurlaneti_donne] SET ANSI_PADDING OFF 
GO

ALTER DATABASE [rodrigofurlaneti_donne] SET ANSI_WARNINGS OFF 
GO

ALTER DATABASE [rodrigofurlaneti_donne] SET ARITHABORT OFF 
GO

ALTER DATABASE [rodrigofurlaneti_donne] SET AUTO_CLOSE OFF 
GO

ALTER DATABASE [rodrigofurlaneti_donne] SET AUTO_SHRINK OFF 
GO

ALTER DATABASE [rodrigofurlaneti_donne] SET AUTO_UPDATE_STATISTICS ON 
GO

ALTER DATABASE [rodrigofurlaneti_donne] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO

ALTER DATABASE [rodrigofurlaneti_donne] SET CURSOR_DEFAULT  GLOBAL 
GO

ALTER DATABASE [rodrigofurlaneti_donne] SET CONCAT_NULL_YIELDS_NULL OFF 
GO

ALTER DATABASE [rodrigofurlaneti_donne] SET NUMERIC_ROUNDABORT OFF 
GO

ALTER DATABASE [rodrigofurlaneti_donne] SET QUOTED_IDENTIFIER OFF 
GO

ALTER DATABASE [rodrigofurlaneti_donne] SET RECURSIVE_TRIGGERS OFF 
GO

ALTER DATABASE [rodrigofurlaneti_donne] SET  ENABLE_BROKER 
GO

ALTER DATABASE [rodrigofurlaneti_donne] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO

ALTER DATABASE [rodrigofurlaneti_donne] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO

ALTER DATABASE [rodrigofurlaneti_donne] SET TRUSTWORTHY OFF 
GO

ALTER DATABASE [rodrigofurlaneti_donne] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO

ALTER DATABASE [rodrigofurlaneti_donne] SET PARAMETERIZATION SIMPLE 
GO

ALTER DATABASE [rodrigofurlaneti_donne] SET READ_COMMITTED_SNAPSHOT OFF 
GO

ALTER DATABASE [rodrigofurlaneti_donne] SET HONOR_BROKER_PRIORITY OFF 
GO

ALTER DATABASE [rodrigofurlaneti_donne] SET RECOVERY FULL 
GO

ALTER DATABASE [rodrigofurlaneti_donne] SET  MULTI_USER 
GO

ALTER DATABASE [rodrigofurlaneti_donne] SET PAGE_VERIFY CHECKSUM  
GO

ALTER DATABASE [rodrigofurlaneti_donne] SET DB_CHAINING OFF 
GO

ALTER DATABASE [rodrigofurlaneti_donne] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO

ALTER DATABASE [rodrigofurlaneti_donne] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO

ALTER DATABASE [rodrigofurlaneti_donne] SET DELAYED_DURABILITY = DISABLED 
GO

ALTER DATABASE [rodrigofurlaneti_donne] SET QUERY_STORE = OFF
GO

ALTER DATABASE [rodrigofurlaneti_donne] SET  READ_WRITE 
GO


USE [rodrigofurlaneti_donne]
GO

/****** Object:  Table [dbo].[CategoryTable]    Script Date: 19/10/2021 09:48:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CategoryTable](
	[CategoryId] [int] IDENTITY(1,1) NOT NULL,
	[CategoryName] [varchar](50) NOT NULL,
 CONSTRAINT [PK_CategoryTable] PRIMARY KEY CLUSTERED 
(
	[CategoryId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


USE [rodrigofurlaneti_donne]
GO

/****** Object:  Table [dbo].[CommandTable]    Script Date: 19/10/2021 09:48:46 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CommandTable](
	[CommandId] [int] IDENTITY(1,1) NOT NULL,
	[CustomerId] [int] NOT NULL,
	[StartDateAndTime] [datetime] NOT NULL,
	[EndDateAndTime] [datetime] NOT NULL,
 CONSTRAINT [PK_CommandTable] PRIMARY KEY CLUSTERED 
(
	[CommandId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


USE [rodrigofurlaneti_donne]
GO

/****** Object:  Table [dbo].[CustomerTable]    Script Date: 19/10/2021 09:49:04 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[CustomerTable](
	[CustomerId] [int] IDENTITY(1,1) NOT NULL,
	[CustomerName] [varchar](50) NOT NULL,
	[Telephone] [varchar](50) NOT NULL,
	[Address] [varchar](50) NOT NULL,
 CONSTRAINT [PK_CustomerTable] PRIMARY KEY CLUSTERED 
(
	[CustomerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


USE [rodrigofurlaneti_donne]
GO

/****** Object:  Table [dbo].[OrderTable]    Script Date: 19/10/2021 09:49:19 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[OrderTable](
	[OrderId] [int] NOT NULL,
	[CommandsId] [int] NOT NULL,
	[ProductId] [int] NOT NULL,
	[TheAmount] [int] NOT NULL,
 CONSTRAINT [PK_OrderTable] PRIMARY KEY CLUSTERED 
(
	[OrderId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[OrderTable]  WITH CHECK ADD  CONSTRAINT [FK_ProductTable_OrderTable] FOREIGN KEY([OrderId])
REFERENCES [dbo].[OrderTable] ([OrderId])
GO

ALTER TABLE [dbo].[OrderTable] CHECK CONSTRAINT [FK_ProductTable_OrderTable]
GO


USE [rodrigofurlaneti_donne]
GO

/****** Object:  Table [dbo].[ProductTable]    Script Date: 19/10/2021 09:49:35 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[ProductTable](
	[ProductId] [int] IDENTITY(1,1) NOT NULL,
	[ProductName] [varchar](100) NOT NULL,
	[CategoryId] [int] NOT NULL,
	[CostPrice] [money] NOT NULL,
	[SalePrice] [money] NOT NULL,
	[QuantityStock] [int] NOT NULL,
	[MinimumStockQuantity] [int] NOT NULL,
	[TotalValueCostOfInventory] [money] NOT NULL,
	[TotalValueSaleStock] [money] NOT NULL,
	[Status] [bit] NOT NULL,
 CONSTRAINT [PK_ProductTable] PRIMARY KEY CLUSTERED 
(
	[ProductId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[ProductTable] ADD  DEFAULT ((1)) FOR [Status]
GO


USE [rodrigofurlaneti_donne]
GO

/****** Object:  Table [dbo].[UserTable]    Script Date: 19/10/2021 09:50:01 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[UserTable](
	[UserId] [int] NOT NULL,
	[UserName] [varchar](50) NOT NULL
) ON [PRIMARY]
GO

USE [rodrigofurlaneti_donne]
GO

/****** Object:  StoredProcedure [dbo].[USP_DeleteCategory]    Script Date: 19/10/2021 09:50:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_DeleteCategory](@CategoryId INTEGER)
AS
BEGIN
	SET NOCOUNT ON;
	DELETE FROM dbo.CategoryTable WHERE CategoryId = @CategoryId;
END
GO


USE [rodrigofurlaneti_donne]
GO

/****** Object:  StoredProcedure [dbo].[USP_DeleteCommand]    Script Date: 19/10/2021 09:50:50 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_DeleteCommand](@CommandId INTEGER)
AS
BEGIN
	SET NOCOUNT ON;
	DELETE FROM dbo.CommandTable WHERE CommandId = @CommandId;
END
GO


USE [rodrigofurlaneti_donne]
GO

/****** Object:  StoredProcedure [dbo].[USP_DeleteCustomer]    Script Date: 19/10/2021 09:51:10 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_DeleteCustomer](@CustomerId INTEGER)
AS
BEGIN
	SET NOCOUNT ON;
	DELETE FROM dbo.CustomerTable WHERE CustomerId = @CustomerId;
END
GO


USE [rodrigofurlaneti_donne]
GO

/****** Object:  StoredProcedure [dbo].[USP_DeleteProduct]    Script Date: 19/10/2021 09:51:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_DeleteProduct](@ProductId INTEGER)
AS
BEGIN
	SET NOCOUNT ON;
	DELETE FROM dbo.ProductTable WHERE ProductId = @ProductId;
END
GO


USE [rodrigofurlaneti_donne]
GO

/****** Object:  StoredProcedure [dbo].[USP_GetAllCategories]    Script Date: 19/10/2021 09:51:48 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_GetAllCategories]
AS
BEGIN
	SET NOCOUNT ON;
	SELECT * FROM rodrigofurlaneti_donne.dbo.CategoryTable;
END
GO


USE [rodrigofurlaneti_donne]
GO
/****** Object:  StoredProcedure [dbo].[USP_GetAllCommands]    Script Date: 19/10/2021 09:52:00 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[USP_GetAllCommands]
AS
BEGIN
	SET NOCOUNT ON;
	SELECT COMM.*, CUST.*
		FROM rodrigofurlaneti_donne.dbo.CommandTable AS COMM
			INNER JOIN rodrigofurlaneti_donne.dbo.CustomerTable AS CUST ON CUST.CustomerId = COMM.CustomerId
END
USE [rodrigofurlaneti_donne]
GO
/****** Object:  StoredProcedure [dbo].[USP_GetAllCustomers]    Script Date: 19/10/2021 09:52:09 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[USP_GetAllCustomers]
AS
BEGIN
	SET NOCOUNT ON;
	SELECT * FROM rodrigofurlaneti_donne.dbo.CustomerTable;
END
USE [rodrigofurlaneti_donne]
GO
/****** Object:  StoredProcedure [dbo].[USP_GetAllProducts]    Script Date: 19/10/2021 09:52:19 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[USP_GetAllProducts]
AS
BEGIN
	SET NOCOUNT ON;
	SELECT PROD.*, CATE.*
		FROM rodrigofurlaneti_donne.dbo.ProductTable AS PROD
			INNER JOIN rodrigofurlaneti_donne.dbo.CategoryTable AS CATE ON CATE.CategoryId = PROD.CategoryId
END
USE [rodrigofurlaneti_donne]
GO
/****** Object:  StoredProcedure [dbo].[USP_GetByIdCategory]    Script Date: 19/10/2021 09:52:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[USP_GetByIdCategory] (@CategoryId INTEGER)
AS
BEGIN
	SET NOCOUNT ON;
	SELECT * 
		FROM dbo.CategoryTable 
			WHERE CategoryId = @CategoryId;
END
USE [rodrigofurlaneti_donne]
GO
/****** Object:  StoredProcedure [dbo].[USP_GetByIdCommand]    Script Date: 19/10/2021 09:52:38 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[USP_GetByIdCommand] (@CommandId INTEGER)
AS
BEGIN
	SET NOCOUNT ON;
	SELECT COMM.*, CUST.*
		FROM rodrigofurlaneti_donne.dbo.CommandTable AS COMM
			INNER JOIN rodrigofurlaneti_donne.dbo.CustomerTable AS CUST ON CUST.CustomerId = COMM.CustomerId
				WHERE COMM.CommandId = @CommandId;
END
USE [rodrigofurlaneti_donne]
GO
/****** Object:  StoredProcedure [dbo].[USP_GetByIdCustomer]    Script Date: 19/10/2021 09:52:46 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[USP_GetByIdCustomer] (@CustomerId INTEGER)
AS
BEGIN
	SET NOCOUNT ON;
	SELECT * 
		FROM dbo.CustomerTable 
			WHERE CustomerId = @CustomerId;
END
USE [rodrigofurlaneti_donne]
GO

/****** Object:  StoredProcedure [dbo].[USP_GetByIdProduct]    Script Date: 19/10/2021 09:52:58 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_GetByIdProduct] (@ProductId INTEGER)
AS
BEGIN
	SET NOCOUNT ON;
	SELECT PROD.*, CATE.*
		FROM rodrigofurlaneti_donne.dbo.ProductTable AS PROD
			INNER JOIN rodrigofurlaneti_donne.dbo.CategoryTable AS CATE ON CATE.CategoryId = PROD.CategoryId
				WHERE PROD.ProductId = @ProductId;
END
GO


USE [rodrigofurlaneti_donne]
GO

/****** Object:  StoredProcedure [dbo].[USP_InsertCategory]    Script Date: 19/10/2021 09:53:09 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_InsertCategory](@CategoryName VARCHAR(50))
AS
BEGIN
	SET NOCOUNT ON;
	INSERT INTO dbo.CategoryTable (CategoryName) VALUES (@CategoryName);
END
GO


USE [rodrigofurlaneti_donne]
GO

/****** Object:  StoredProcedure [dbo].[USP_InsertCommand]    Script Date: 19/10/2021 09:53:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_InsertCommand](@CustomerId INTEGER, @StartDateAndTime DATETIME, @EndDateAndTime DATETIME)
AS
BEGIN
	SET NOCOUNT ON;
	INSERT INTO dbo.CommandTable (CustomerId, StartDateAndTime, EndDateAndTime) VALUES (@CustomerId, @StartDateAndTime, @EndDateAndTime);
END
GO


USE [rodrigofurlaneti_donne]
GO

/****** Object:  StoredProcedure [dbo].[USP_InsertCustomer]    Script Date: 19/10/2021 09:53:33 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_InsertCustomer](@CustomerName VARCHAR(50), @Telephone VARCHAR(50), @Address VARCHAR(50))
AS
BEGIN
	SET NOCOUNT ON;
	INSERT INTO dbo.CustomerTable (CustomerName, Telephone, Address) VALUES (@CustomerName, @Telephone, @Address);
END
GO


USE [rodrigofurlaneti_donne]
GO

/****** Object:  StoredProcedure [dbo].[USP_InsertProduct]    Script Date: 19/10/2021 09:53:46 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_InsertProduct](	@CategoryId INTEGER, 
											@ProductName VARCHAR(100), 
											@CostPrice MONEY,
											@SalePrice MONEY,
											@QuantityStock INTEGER,
											@MinimumStockQuantity INTEGER,
											@TotalValueCostOfInventory MONEY,
											@TotalValueSaleStock MONEY,
											@Status BIT)
AS
BEGIN
	SET NOCOUNT ON;
	INSERT INTO dbo.ProductTable (	CategoryId, 
									ProductName, 
									CostPrice, 
									SalePrice, 
									QuantityStock, 
									MinimumStockQuantity, 
									TotalValueCostOfInventory, 
									TotalValueSaleStock,
									Status) 
						VALUES (	@CategoryId, 
									@ProductName, 
									@CostPrice,
									@SalePrice,
									@QuantityStock,
									@MinimumStockQuantity,
									@TotalValueCostOfInventory,
									@TotalValueSaleStock,
									@Status);
END
GO


USE [rodrigofurlaneti_donne]
GO

/****** Object:  StoredProcedure [dbo].[USP_UpdateCategory]    Script Date: 19/10/2021 09:53:59 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[USP_UpdateCategory](@CategoryId INTEGER, @CategoryName VARCHAR(50))
AS
BEGIN
	SET NOCOUNT ON;
	UPDATE dbo.CategoryTable 
		SET CategoryName = @CategoryName
			WHERE CategoryId = @CategoryId
END
GO


USE [rodrigofurlaneti_donne]
GO
/****** Object:  StoredProcedure [dbo].[USP_UpdateCommand]    Script Date: 19/10/2021 09:54:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[USP_UpdateCommand](@CommandId INTEGER, @CustomerId INTEGER, @StartDateAndTime DATETIME, @EndDateAndTime DATETIME)
AS
BEGIN
	SET NOCOUNT ON;
	UPDATE dbo.CommandTable 
		SET CustomerId = @CustomerId,
			StartDateAndTime = @StartDateAndTime,
			EndDateAndTime = @EndDateAndTime
			WHERE CommandId = @CommandId
END
USE [rodrigofurlaneti_donne]
GO
/****** Object:  StoredProcedure [dbo].[USP_UpdateCustomer]    Script Date: 19/10/2021 09:54:29 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[USP_UpdateCustomer](@CustomerId INTEGER, @CustomerName VARCHAR(50), @Telephone VARCHAR(50), @Address VARCHAR(50))
AS
BEGIN
	SET NOCOUNT ON;
	UPDATE dbo.CustomerTable 
		SET CustomerName = @CustomerName,
			Telephone = @Telephone,
			Address = @Address
			WHERE CustomerId = @CustomerId
END
USE [rodrigofurlaneti_donne]
GO
/****** Object:  StoredProcedure [dbo].[USP_UpdateProduct]    Script Date: 19/10/2021 09:54:40 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[USP_UpdateProduct](	@ProductId INTEGER, 
											@CategoryId INTEGER, 
											@ProductName VARCHAR(100), 
											@CostPrice MONEY,
											@SalePrice MONEY,
											@QuantityStock INTEGER,
											@MinimumStockQuantity INTEGER,
											@TotalValueCostOfInventory MONEY,
											@TotalValueSaleStock MONEY,
											@Status BIT)
AS
BEGIN
	SET NOCOUNT ON;
	UPDATE dbo.ProductTable 
		SET CategoryId = @CategoryId,
			ProductName = @ProductName,
			CostPrice = @CostPrice,
			SalePrice = @SalePrice,
			QuantityStock = @QuantityStock,
			MinimumStockQuantity = @MinimumStockQuantity,
			TotalValueCostOfInventory = @TotalValueCostOfInventory,
			TotalValueSaleStock = @TotalValueSaleStock,
			Status = @Status
			WHERE ProductId = @ProductId
END




