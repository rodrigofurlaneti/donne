﻿using Donne.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Donne.Dal
{
    public class OutOfCashRepository
    {
        #region Properties
        private readonly IConfigurationRoot configurationRoot;
        #endregion

        #region Constructors
        public OutOfCashRepository()
        {
            IConfigurationBuilder configurationBuilder = new ConfigurationBuilder().SetBasePath(Environment.CurrentDirectory).AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
            configurationRoot = configurationBuilder.Build();
        }
        #endregion

        #region Methods 

        public IEnumerable<OutOfCashModel> GetAllCategories()
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            List<OutOfCashModel> listOutOfCashModel = new List<OutOfCashModel>();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetAllOutOfCash", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    OutOfCashModel OutOfCash = new OutOfCashModel();
                    OutOfCash.OutOfCashId = Convert.ToInt32(rdr["OutOfCashId"]);
                    OutOfCash.OutOfCashName = rdr["OutOfCashName"].ToString();
                    OutOfCash.OutOfCashProvider = rdr["OutOfCashProvider"].ToString();
                    OutOfCash.OutOfCashValue = Convert.ToDecimal(rdr["OutOfCashValue"]);
                    OutOfCash.OutOfCashDate = Convert.ToDateTime(rdr["OutOfCashDate"]);
                    listOutOfCashModel.Add(OutOfCash);
                }
            }
            return listOutOfCashModel;
        }

        public OutOfCashModel GetById(int id)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            OutOfCashModel OutOfCash = new OutOfCashModel();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetByIdOutOfCash", con);
                cmd.Parameters.AddWithValue("@OutOfCashId", id);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    OutOfCash.OutOfCashId = Convert.ToInt32(rdr["OutOfCashId"]);
                    OutOfCash.OutOfCashName = rdr["OutOfCashName"].ToString();
                    OutOfCash.OutOfCashProvider = rdr["OutOfCashProvider"].ToString();
                    OutOfCash.OutOfCashValue = Convert.ToDecimal(rdr["OutOfCashValue"]);
                    OutOfCash.OutOfCashDate = Convert.ToDateTime(rdr["OutOfCashDate"]);
                }
            }
            return OutOfCash;
        }

        public void Insert(OutOfCashModel OutOfCashModel)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("USP_InsertOutOfCash", con);
            cmd.Parameters.AddWithValue("@OutOfCashName", OutOfCashModel.OutOfCashName);
            cmd.Parameters.AddWithValue("@OutOfCashProvider", OutOfCashModel.OutOfCashProvider);
            cmd.Parameters.AddWithValue("@OutOfCashValue", OutOfCashModel.OutOfCashValue);
            cmd.Parameters.AddWithValue("@OutOfCashDate", OutOfCashModel.OutOfCashDate);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void Delete(int OutOfCashId)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("USP_DeleteOutOfCash", con);
            cmd.Parameters.AddWithValue("@OutOfCashId", OutOfCashId);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void Update(OutOfCashModel OutOfCashModel)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("USP_UpdateOutOfCash", con);
            cmd.Parameters.AddWithValue("@OutOfCashId", OutOfCashModel.OutOfCashId);
            cmd.Parameters.AddWithValue("@OutOfCashName", OutOfCashModel.OutOfCashName);
            cmd.Parameters.AddWithValue("@OutOfCashProvider", OutOfCashModel.OutOfCashProvider);
            cmd.Parameters.AddWithValue("@OutOfCashValue", OutOfCashModel.OutOfCashValue);
            cmd.Parameters.AddWithValue("@OutOfCashDate", OutOfCashModel.OutOfCashDate);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        #endregion
    }
}
