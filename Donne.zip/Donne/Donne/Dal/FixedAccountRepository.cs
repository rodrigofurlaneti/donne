﻿using Donne.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Donne.Dal
{
    public class FixedAccountRepository
    {
        #region Properties
        private readonly IConfigurationRoot configurationRoot;
        #endregion

        #region Constructors
        public FixedAccountRepository()
        {
            IConfigurationBuilder configurationBuilder = new ConfigurationBuilder().SetBasePath(Environment.CurrentDirectory).AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
            configurationRoot = configurationBuilder.Build();
        }
        #endregion

        #region Methods
        public IEnumerable<FixedAccountModel> GetAllFixedAccount()
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            List<FixedAccountModel> listFixedAccount = new List<FixedAccountModel>();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetAllFixedAccount", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    FixedAccountModel fixedAccount = new FixedAccountModel();
                    fixedAccount.FixedAccountId = Convert.ToInt32(rdr["FixedAccountId"]);
                    fixedAccount.FixedAccountName = rdr["FixedAccountName"].ToString();
                    fixedAccount.FixedAccountMonth = Convert.ToDecimal(rdr["FixedAccountMonth"]);
                    fixedAccount.FixedAccountWeek = Convert.ToDecimal(rdr["FixedAccountWeek"]);
                    fixedAccount.FixedAccountDay = Convert.ToDecimal(rdr["FixedAccountDay"]);
                    listFixedAccount.Add(fixedAccount);
                }
            }
            return listFixedAccount;
        }

        public FixedAccountModel GetById(int id)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            FixedAccountModel fixedAccount = new FixedAccountModel();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetByIdFixedAccount", con);
                cmd.Parameters.AddWithValue("@FixedAccountId", id);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    fixedAccount.FixedAccountId = Convert.ToInt32(rdr["FixedAccountId"]);
                    fixedAccount.FixedAccountName = rdr["FixedAccountName"].ToString();
                    fixedAccount.FixedAccountMonth = Convert.ToDecimal(rdr["FixedAccountMonth"]);
                    fixedAccount.FixedAccountWeek = Convert.ToDecimal(rdr["FixedAccountWeek"]);
                    fixedAccount.FixedAccountDay = Convert.ToDecimal(rdr["FixedAccountDay"]);

                }
            }
            return fixedAccount;
        }

        public void Insert(FixedAccountModel fixedAccount)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("USP_InsertFixedAccount", con);
            cmd.Parameters.AddWithValue("@FixedAccountName", fixedAccount.FixedAccountName);
            cmd.Parameters.AddWithValue("@FixedAccountMonth", fixedAccount.FixedAccountMonth);
            cmd.Parameters.AddWithValue("@FixedAccountWeek", fixedAccount.FixedAccountWeek);
            cmd.Parameters.AddWithValue("@FixedAccountDay", fixedAccount.FixedAccountDay);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void Delete(int fixedAccountId)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("USP_DeleteFixedAccount", con);
            cmd.Parameters.AddWithValue("@FixedAccountId", fixedAccountId);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void Update(FixedAccountModel fixedAccount)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("USP_UpdateFixedAccount", con);
            cmd.Parameters.AddWithValue("@FixedAccountId", fixedAccount.FixedAccountId);
            cmd.Parameters.AddWithValue("@FixedAccountName", fixedAccount.FixedAccountName);
            cmd.Parameters.AddWithValue("@FixedAccountMonth", fixedAccount.FixedAccountMonth);
            cmd.Parameters.AddWithValue("@FixedAccountWeek", fixedAccount.FixedAccountWeek);
            cmd.Parameters.AddWithValue("@FixedAccountDay", fixedAccount.FixedAccountDay);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public FixedAccountModel GetFixedAccountMonth()
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            FixedAccountModel fixedAccount = new FixedAccountModel();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetFixedAccountMonth", con);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    fixedAccount.FixedAccountMonth = Convert.ToDecimal(rdr["FixedAccountMonth"]);
                }
            }
            return fixedAccount;
        }

        public FixedAccountModel GetFixedAccountWeek()
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            FixedAccountModel fixedAccount = new FixedAccountModel();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetFixedAccountWeek", con);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    fixedAccount.FixedAccountWeek = Convert.ToDecimal(rdr["FixedAccountWeek"]);
                }
            }
            return fixedAccount;
        }

        public FixedAccountModel GetFixedAccountDay()
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            FixedAccountModel fixedAccount = new FixedAccountModel();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetFixedAccountDay", con);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    fixedAccount.FixedAccountDay = Convert.ToDecimal(rdr["FixedAccountDay"]);
                }
            }
            return fixedAccount;
        }

        public FixedAccountModel GetMetaCemFixedAccountMonth()
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            FixedAccountModel fixedAccount = new FixedAccountModel();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetFixedAccountMonthMetaCem", con);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    fixedAccount.FixedAccountMonth = Convert.ToDecimal(rdr["FixedAccountMonth"]);
                }
            }
            return fixedAccount;
        }

        public FixedAccountModel GetMetaCemFixedAccountWeek()
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            FixedAccountModel fixedAccount = new FixedAccountModel();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetFixedAccountWeekMetaCem", con);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    fixedAccount.FixedAccountWeek = Convert.ToDecimal(rdr["FixedAccountWeek"]);
                }
            }
            return fixedAccount;
        }

        public FixedAccountModel GetMetaCemFixedAccountDay()
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            FixedAccountModel fixedAccount = new FixedAccountModel();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetFixedAccountDayMetaCem", con);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    fixedAccount.FixedAccountDay = Convert.ToDecimal(rdr["FixedAccountDay"]);
                }
            }
            return fixedAccount;
        }

        public FixedAccountModel GetMetaCinquentaFixedAccountMonth()
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            FixedAccountModel fixedAccount = new FixedAccountModel();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetFixedAccountMonthMetaCinquenta", con);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    fixedAccount.FixedAccountMonth = Convert.ToDecimal(rdr["FixedAccountMonth"]);
                }
            }
            return fixedAccount;
        }

        public FixedAccountModel GetMetaCinquentaFixedAccountWeek()
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            FixedAccountModel fixedAccount = new FixedAccountModel();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetFixedAccountWeekMetaCinquenta", con);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    fixedAccount.FixedAccountWeek = Convert.ToDecimal(rdr["FixedAccountWeek"]);
                }
            }
            return fixedAccount;
        }

        public FixedAccountModel GetMetaCinquentaFixedAccountDay()
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            FixedAccountModel fixedAccount = new FixedAccountModel();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetFixedAccountDayMetaCinquenta", con);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    fixedAccount.FixedAccountDay = Convert.ToDecimal(rdr["FixedAccountDay"]);
                }
            }
            return fixedAccount;
        }

        #endregion
    }
}
