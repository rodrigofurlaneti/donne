﻿using Donne.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Donne.Dal
{
    public class OrderRepository
    {
        #region Properties
        private readonly IConfigurationRoot configurationRoot;
        #endregion

        #region Constructor
        public OrderRepository()
        {
            IConfigurationBuilder configurationBuilder = new ConfigurationBuilder().SetBasePath(Environment.CurrentDirectory).AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
            configurationRoot = configurationBuilder.Build();
        }
        #endregion

        #region Methods 

        public IEnumerable<OrderModel> GetAllOrders()
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            List<OrderModel> listOrderModel = new List<OrderModel>();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetAllOrders", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    OrderModel orderModel = new OrderModel();
                    orderModel.OrderId = Convert.ToInt32(rdr["OrderId"]);
                    orderModel.ProductId = Convert.ToInt32(rdr["ProductId"].ToString());
                    orderModel.ProductName = Convert.ToString(rdr["ProductName"]);
                    orderModel.CommandId = Convert.ToInt32(rdr["CommandId"].ToString());
                    orderModel.CustomerName = Convert.ToString(rdr["CustomerName"]);
                    orderModel.ProductQuantity = Convert.ToInt32(rdr["ProductQuantity"].ToString());
                    orderModel.Note = Convert.ToString(rdr["Note"]);
                    listOrderModel.Add(orderModel);
                }
            }
            return listOrderModel;
        }

        public OrderModel GetById(int id)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            OrderModel orderModel = new OrderModel();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetByIdOrder", con);
                cmd.Parameters.AddWithValue("@OrderId", id);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    orderModel.OrderId = Convert.ToInt32(rdr["OrderId"]);
                    orderModel.ProductId = Convert.ToInt32(rdr["ProductId"]);
                    orderModel.CommandId = Convert.ToInt32(rdr["CommandId"]);
                    orderModel.ProductQuantity = Convert.ToInt32(rdr["ProductQuantity"]);
                    orderModel.Note = (rdr["Note"]).ToString();
                }
            }
            return orderModel;
        }

        public void Insert(OrderModel orderModel)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("USP_InsertOrder", con);
            cmd.Parameters.AddWithValue("@ProductId", orderModel.ProductId);
            cmd.Parameters.AddWithValue("@CommandId", orderModel.CommandId);
            cmd.Parameters.AddWithValue("@ProductQuantity", orderModel.ProductQuantity);
            cmd.Parameters.AddWithValue("@Note", orderModel.Note);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void Delete(int orderId)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("USP_DeleteOrder", con);
            cmd.Parameters.AddWithValue("@OrderId", orderId);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void Update(OrderModel orderModel)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("USP_UpdateOrder", con);
            cmd.Parameters.AddWithValue("@OrderId", orderModel.OrderId);
            cmd.Parameters.AddWithValue("@ProductId", orderModel.ProductId);
            cmd.Parameters.AddWithValue("@CommandId", orderModel.CommandId);
            cmd.Parameters.AddWithValue("@ProductQuantity", orderModel.ProductQuantity);
            cmd.Parameters.AddWithValue("@Note", orderModel.Note);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            con.Close();
        }
        #endregion
    }
}