﻿using Donne.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Donne.Dal.Customer
{
    public class CustomerRepository
    {
        #region Properties
        private readonly IConfigurationRoot configurationRoot;
        #endregion

        #region Constructor
        public CustomerRepository()
        {
            IConfigurationBuilder configurationBuilder = new ConfigurationBuilder().SetBasePath(Environment.CurrentDirectory).AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
            configurationRoot = configurationBuilder.Build();
        }
        #endregion

        #region Methods 

        public List<CustomerModel> GetAllCustomers()
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            List<CustomerModel> listCustomerModel = new List<CustomerModel>();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetAllCustomers", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    CustomerModel Customer = new CustomerModel();
                    Customer.CustomerId = Convert.ToInt32(rdr["CustomerId"]);
                    Customer.CustomerName = rdr["CustomerName"].ToString();
                    Customer.Telephone = rdr["Telephone"].ToString();
                    Customer.Address = rdr["Address"].ToString();
                    listCustomerModel.Add(Customer);
                }
            }
            return listCustomerModel;
        }

        public CustomerModel GetById(int id)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            CustomerModel CustomerModel = new CustomerModel();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetByIdCustomer", con);
                cmd.Parameters.AddWithValue("@CustomerId", id);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    CustomerModel.CustomerId = Convert.ToInt32(rdr["CustomerId"]);
                    CustomerModel.CustomerName = rdr["CustomerName"].ToString();
                    CustomerModel.Telephone = rdr["Telephone"].ToString();
                    CustomerModel.Address = rdr["Address"].ToString();
                }
            }
            return CustomerModel;
        }

        public void Insert(CustomerModel customerModel)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("USP_InsertCustomer", con);
            cmd.Parameters.AddWithValue("@CustomerName", customerModel.CustomerName);
            cmd.Parameters.AddWithValue("@Telephone", customerModel.Telephone);
            cmd.Parameters.AddWithValue("@Address", customerModel.Address);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void Delete(int CustomerId)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("USP_DeleteCustomer", con);
            cmd.Parameters.AddWithValue("@CustomerId", CustomerId);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void Update(CustomerModel customerModel)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("USP_UpdateCustomer", con);
            cmd.Parameters.AddWithValue("@CustomerId", customerModel.CustomerId);
            cmd.Parameters.AddWithValue("@CustomerName", customerModel.CustomerName);
            cmd.Parameters.AddWithValue("@Telephone", customerModel.Telephone);
            cmd.Parameters.AddWithValue("@Address", customerModel.Address);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        #endregion
    }
}
