﻿namespace Donne.Models
{
    public class AccountItemModel
    {
        public string ProductName { get; set; }
        public int ProductQuantity { get; set; }
        public decimal SalePrice { get; set; }
        public decimal SubTotal { get; set; }
    }
}
