﻿namespace Donne.Models
{
    public class FormOfPaymentModel
    {
        public int FormOfPaymentId { get; set; }
        public string FormOfPaymentName { get; set; }
    }
}
