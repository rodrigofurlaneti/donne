﻿using System;
using System.Collections.Generic;

namespace Donne.Models
{
    public class AccountModel
    {
        public int CommandId { get; set; }
        public DateTime StartDateAndTime { get; set; }
        public string CustomerName { get; set; }
        public List<AccountItemModel> listAccountItemModels { get; set; }
        public decimal TotalAccountValue { get; set; }
    }
}
