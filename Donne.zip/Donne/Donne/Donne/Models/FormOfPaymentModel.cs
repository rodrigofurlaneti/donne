﻿namespace Donne.Models
{
    public class FormOfPaymentModel
    {
        public int FormOfPaymentId { get; set; }
        public string FormOfPaymentName { get; set; }
        public int FormOfPaymentValueDebit { get; set; }
        public int FormOfPaymentValueCredit { get; set; }
        public int FormOfPaymentValueMoney { get; set; }
        public int FormOfPaymentValuePix { get; set; }

    }
}
