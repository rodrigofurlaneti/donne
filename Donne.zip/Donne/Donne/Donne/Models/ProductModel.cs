﻿namespace Donne.Models
{
    public class ProductModel
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
        public decimal CostPrice { get; set; }
        public decimal SalePrice { get; set; }
        public int QuantityStock { get; set; }
        public int MinimumStockQuantity { get; set; }
        public decimal TotalValueCostOfInventory { get; set; }
        public decimal TotalValueSaleStock { get; set; }
        public bool Status { get; set; }
        public bool NeedToPrint { get; set; }
    }
}
