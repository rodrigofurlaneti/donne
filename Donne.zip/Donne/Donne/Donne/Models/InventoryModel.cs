﻿
namespace Donne.Models
{
	public class InventoryModel
	{
		public decimal Inventory { get; set; }
		public decimal Stock { get; set; }
		public decimal Profit { get; set; }
	}
}
