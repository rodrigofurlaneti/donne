﻿using System;

namespace Donne.Models
{
    public class MonthlyBillingModel
    {
        public DateTime DateNumber { get; set; }
        public int DayNumber { get; set; }
        public decimal Amount { get; set; }
    }
}
