﻿using System;
using System.Collections.Generic;

namespace Donne.Models
{
    public class OrderModel
    {
        public int OrderId { get; set; }
        public int CommandId { get; set; }
        public string CustomerName { get; set; }
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public int ProductQuantity { get; set; }
        public string Note { get; set; }
        public DateTime OrderDateAndTime { get; set; }
    }
}
