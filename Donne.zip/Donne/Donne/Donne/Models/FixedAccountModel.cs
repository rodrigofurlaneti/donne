﻿namespace Donne.Models
{
    public class FixedAccountModel
    {
        public int FixedAccountId { get; set; }
        public string FixedAccountName { get; set; }
        public decimal FixedAccountMonth { get; set; }
        public decimal FixedAccountWeek { get; set; }
        public decimal FixedAccountDay { get; set; }
    }
}
