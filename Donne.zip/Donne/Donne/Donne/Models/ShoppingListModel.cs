﻿namespace Donne.Models
{
	public class ShoppingListModel : ProductModel
	{
		public int QuantityOfItemToBuy { get; set; }
	}
}
