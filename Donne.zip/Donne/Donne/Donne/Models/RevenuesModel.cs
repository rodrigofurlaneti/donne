﻿namespace Donne.Models
{
	public class RevenuesModel
	{
		public int MonthNumber { get; set; }
		public string MonthName { get; set; }
		public decimal Amount { get; set; }
	}
}
