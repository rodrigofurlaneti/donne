﻿namespace Donne.Models
{
    public class ActiveModel
    {
        public int ActiveId { get; set; }
        public string ActiveName { get; set; }
        public decimal ActiveValue { get; set; }
    }
}
