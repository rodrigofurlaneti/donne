﻿using System;

namespace Donne.Models
{
    public class PaymentModel
    {
        public int PaymentId { get; set; }
        public int CommandId { get; set; }
        public string? CustomerName { get; set; }
        public int FormOfPaymentId { get; set; }
        public string? FormOfPaymentName { get; set; }
        public DateTime DischargeDate { get; set; }
        public bool Status { get; set; }
        public decimal Amount { get; set; }
    }
}
