﻿namespace Donne.Models
{
    public class CustomerModel
    {
        public int CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string Telephone { get; set; }
        public string Address { get; set; }
    }
}
