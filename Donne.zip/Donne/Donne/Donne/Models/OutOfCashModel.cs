﻿using System;

namespace Donne.Models
{
    public class OutOfCashModel
    {
        public int OutOfCashId { get; set; }
        public string OutOfCashName { get; set; }
        public string OutOfCashProvider { get; set; }
        public decimal OutOfCashValue { get; set; }
        public DateTime OutOfCashDate { get; set; }

    }
}
