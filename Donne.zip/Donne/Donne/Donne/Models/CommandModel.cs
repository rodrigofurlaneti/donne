﻿using System;

namespace Donne.Models
{
    public class CommandModel
    {
        public int CommandId { get; set; }
        public int CustomerId { get; set; }
        public string CustomerName { get; set; }
        public DateTime StartDateAndTime { get; set; }
        public DateTime? EndDateAndTime { get; set; }
        public bool PaidOut { get; set; }
    }
}
