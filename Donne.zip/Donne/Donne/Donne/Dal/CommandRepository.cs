﻿using Donne.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Donne.Dal
{
    public class CommandRepository
    {
        #region Properties
        private readonly IConfigurationRoot configurationRoot;
        #endregion

        #region Constructor
        public CommandRepository()
        {
            IConfigurationBuilder configurationBuilder = new ConfigurationBuilder().SetBasePath(Environment.CurrentDirectory).AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
            configurationRoot = configurationBuilder.Build();
        }
        #endregion

        #region Methods 

        public IEnumerable<CommandModel> GetAllCommands()
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            List<CommandModel> listCommandModel = new List<CommandModel>();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetAllCommands", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    CommandModel command = new CommandModel();
                    command.CommandId = Convert.ToInt32(rdr["CommandId"]);
                    command.CustomerId = Convert.ToInt32(rdr["CustomerId"]);
                    command.CustomerName = (rdr["CustomerName"]).ToString();
                    command.StartDateAndTime = Convert.ToDateTime(rdr["StartDateAndTime"]);
                    command.EndDateAndTime = Convert.ToDateTime(rdr["EndDateAndTime"]);
                    command.PaidOut = Convert.ToBoolean(rdr["PaidOut"]);
                    listCommandModel.Add(command);
                }
            }
            return listCommandModel;
        }

        public CommandModel GetById(int id)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            CommandModel commandModel = new CommandModel();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetByIdCommand", con);
                cmd.Parameters.AddWithValue("@CommandId", id);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    commandModel.CommandId = Convert.ToInt32(rdr["CommandId"]);
                    commandModel.CustomerId = Convert.ToInt32(rdr["CustomerId"]);
                    commandModel.CustomerName = (rdr["CustomerName"]).ToString();
                    commandModel.StartDateAndTime = Convert.ToDateTime(rdr["StartDateAndTime"]);
                    commandModel.EndDateAndTime = Convert.ToDateTime(rdr["EndDateAndTime"]);
                    commandModel.PaidOut = Convert.ToBoolean(rdr["PaidOut"]);
                }
            }
            return commandModel;
        }

        public void Insert(CommandModel commandModel)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("USP_InsertCommand", con);
            cmd.Parameters.AddWithValue("@CustomerId", commandModel.CustomerId);
            cmd.Parameters.AddWithValue("@StartDateAndTime", DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            cmd.Parameters.AddWithValue("@EndDateAndTime", String.Empty);
            cmd.Parameters.AddWithValue("@PaidOut", commandModel.PaidOut);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void Delete(int CommandId)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("USP_DeleteCommand", con);
            cmd.Parameters.AddWithValue("@CommandId", CommandId);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void Update(CommandModel commandModel)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("USP_UpdateCommand", con);
            cmd.Parameters.AddWithValue("@CommandId", commandModel.CommandId);
            cmd.Parameters.AddWithValue("@CustomerId", commandModel.CustomerId);
            cmd.Parameters.AddWithValue("@StartDateAndTime", commandModel.StartDateAndTime);
            cmd.Parameters.AddWithValue("@EndDateAndTime", commandModel.EndDateAndTime);
            cmd.Parameters.AddWithValue("@PaidOut", commandModel.PaidOut);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        #endregion
    }
}