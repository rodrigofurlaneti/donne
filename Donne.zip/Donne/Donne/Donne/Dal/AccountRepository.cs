﻿using Donne.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Donne.Dal
{
    public class AccountRepository
    {
        #region Properties
        private readonly IConfigurationRoot configurationRoot;
        #endregion

        #region Constructors
        public AccountRepository()
        {
            IConfigurationBuilder configurationBuilder = new ConfigurationBuilder().SetBasePath(Environment.CurrentDirectory).AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
            configurationRoot = configurationBuilder.Build();
        }
        #endregion

        #region Methods

        public List<AccountModel> GetById(int id)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            List<AccountModel> listAccountModel = new List<AccountModel>();
            AccountModel accountModel = new AccountModel();
            accountModel.listAccountItemModels = new List<AccountItemModel>();
            
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetByIdAccount", con);
                cmd.Parameters.AddWithValue("@CommandId", id);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    accountModel.CommandId = Convert.ToInt32(rdr["CommandId"]);
                    accountModel.CustomerName = Convert.ToString(rdr["CustomerName"]);
                    accountModel.StartDateAndTime = Convert.ToDateTime(rdr["StartDateAndTime"]);
                    var accountItemModel = new AccountItemModel();
                    accountItemModel.ProductName = Convert.ToString(rdr["ProductName"]);
                    accountItemModel.ProductQuantity = Convert.ToInt32(rdr["ProductQuantity"]);
                    accountItemModel.SalePrice = Convert.ToDecimal(rdr["SalePrice"]);
                    accountItemModel.SubTotal = Convert.ToDecimal(rdr["SubTotal"]);
                    accountModel.TotalAccountValue = accountModel.TotalAccountValue + accountItemModel.SubTotal;
                    accountModel.listAccountItemModels.Add(accountItemModel);
                }
                listAccountModel.Add(accountModel);
            }
            return listAccountModel;
        }

        #endregion
    }
}
