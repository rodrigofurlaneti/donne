﻿using Donne.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Donne.Dal
{
	public class ShoppingListRepository
	{
		#region Properties
		private readonly IConfigurationRoot configurationRoot;
		#endregion

		#region Constructor
		public ShoppingListRepository()
		{
			IConfigurationBuilder configurationBuilder = new ConfigurationBuilder().SetBasePath(Environment.CurrentDirectory).AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
			configurationRoot = configurationBuilder.Build();
		}
        #endregion

        #region Methods

        public IEnumerable<ShoppingListModel> GetAllShoppingList()
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            List<ShoppingListModel> shoppingListModel = new List<ShoppingListModel>();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetAllShoppingList", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    ShoppingListModel shopping = new ShoppingListModel();
                    shopping.ProductName = Convert.ToString(rdr["ProductName"]);
                    shopping.CostPrice = Convert.ToDecimal(rdr["CostPrice"]);
                    shopping.QuantityOfItemToBuy = Convert.ToInt32(rdr["QuantityOfItemToBuy"]);
                    shoppingListModel.Add(shopping);
                }
            }
            return shoppingListModel;
        }

        #endregion
    }
}
