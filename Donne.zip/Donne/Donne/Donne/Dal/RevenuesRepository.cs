﻿using Donne.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Data;
using System.Data.SqlClient;

namespace Donne.Dal
{
	public class RevenuesRepository
	{
        #region Properties
        private readonly IConfigurationRoot configurationRoot;
        #endregion

        #region Constructor
        public RevenuesRepository()
        {
            IConfigurationBuilder configurationBuilder = new ConfigurationBuilder().SetBasePath(Environment.CurrentDirectory).AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
            configurationRoot = configurationBuilder.Build();
        }
        #endregion

        #region Methods 

        public RevenuesModel GetAllRevenues(int month)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            var revenuesModel = new RevenuesModel();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetAllRevenies", con);
                cmd.Parameters.AddWithValue("@Month", month);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    revenuesModel.Amount = (rdr["Amount"].ToString() != String.Empty) ? Convert.ToDecimal(rdr["Amount"]) : 0;
                }
            }
            return revenuesModel;
        }

        #endregion
    }
}
