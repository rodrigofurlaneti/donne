﻿using Donne.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Donne.Dal
{
    public class FormOfPaymentRepository
    {
        #region Properties
        private readonly IConfigurationRoot configurationRoot;
        #endregion

        #region Constructor
        public FormOfPaymentRepository()
        {
            IConfigurationBuilder configurationBuilder = new ConfigurationBuilder().SetBasePath(Environment.CurrentDirectory).AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
            configurationRoot = configurationBuilder.Build();
        }
        #endregion

        #region Methods 

        public IEnumerable<FormOfPaymentModel> GetAllFormOfPayments()
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            List<FormOfPaymentModel> listFormOfPaymentModel = new List<FormOfPaymentModel>();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetAllFormOfPayments", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    FormOfPaymentModel formOfPayment = new FormOfPaymentModel();
                    formOfPayment.FormOfPaymentId = Convert.ToInt32(rdr["FormOfPaymentId"]);
                    formOfPayment.FormOfPaymentName = rdr["FormOfPaymentName"].ToString();
                    listFormOfPaymentModel.Add(formOfPayment);
                }
            }
            return listFormOfPaymentModel;
        }

        public FormOfPaymentModel GetById(int id)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            FormOfPaymentModel FormOfPaymentModel = new FormOfPaymentModel();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetByIdFormOfPayment", con);
                cmd.Parameters.AddWithValue("@FormOfPaymentId", id);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    FormOfPaymentModel.FormOfPaymentId = Convert.ToInt32(rdr["FormOfPaymentId"]);
                    FormOfPaymentModel.FormOfPaymentName = rdr["FormOfPaymentName"].ToString();
                }
            }
            return FormOfPaymentModel;
        }

        public void Insert(FormOfPaymentModel FormOfPaymentModel)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("USP_InsertFormOfPayment", con);
            cmd.Parameters.AddWithValue("@FormOfPaymentName", FormOfPaymentModel.FormOfPaymentName);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void Delete(int FormOfPaymentId)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("USP_DeleteFormOfPayment", con);
            cmd.Parameters.AddWithValue("@FormOfPaymentId", FormOfPaymentId);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void Update(FormOfPaymentModel FormOfPaymentModel)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("USP_UpdateFormOfPayment", con);
            cmd.Parameters.AddWithValue("@FormOfPaymentId", FormOfPaymentModel.FormOfPaymentId);
            cmd.Parameters.AddWithValue("@FormOfPaymentName", FormOfPaymentModel.FormOfPaymentName);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        #endregion
    }
}
