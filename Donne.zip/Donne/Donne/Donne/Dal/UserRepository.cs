﻿using Donne.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Donne.Dal
{
    public class UserRepository
    {
        #region Properties
        private readonly IConfigurationRoot configurationRoot;
        #endregion

        #region Constructors
        public UserRepository()
        {
            IConfigurationBuilder configurationBuilder = new ConfigurationBuilder().SetBasePath(Environment.CurrentDirectory).AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
            configurationRoot = configurationBuilder.Build();
        }
        #endregion

        #region Methods 

        public IEnumerable<UserModel> GetAllUser()
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            List<UserModel> listUserModel = new List<UserModel>();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetAllUser", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    UserModel User = new UserModel();
                    User.UserId = Convert.ToInt32(rdr["UserId"]);
                    User.UserName = rdr["UserName"].ToString();
                    User.Password = rdr["Password"].ToString();
                    listUserModel.Add(User);
                }
            }
            return listUserModel;
        }

        public UserModel GetByLogin(UserModel user)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            UserModel UserModel = new UserModel();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetByLogin", con);
                cmd.Parameters.AddWithValue("@UserName", user.UserName);
                cmd.Parameters.AddWithValue("@Password", user.Password);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    UserModel.UserId = Convert.ToInt32(rdr["UserId"]);
                    UserModel.UserName = rdr["UserName"].ToString();
                    UserModel.UserName = rdr["Password"].ToString();
                }
            }
            return UserModel;
        }

        public UserModel GetById(int id)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            UserModel UserModel = new UserModel();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetByIdUser", con);
                cmd.Parameters.AddWithValue("@UserId", id);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    UserModel.UserId = Convert.ToInt32(rdr["UserId"]);
                    UserModel.UserName = rdr["UserName"].ToString();
                    UserModel.Password = rdr["Password"].ToString();
                }
            }
            return UserModel;
        }

        public void Insert(UserModel UserModel)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("USP_InsertUser", con);
            cmd.Parameters.AddWithValue("@UserName", UserModel.UserName);
            cmd.Parameters.AddWithValue("@Password", UserModel.Password);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void Delete(int UserId)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("USP_DeleteUser", con);
            cmd.Parameters.AddWithValue("@UserId", UserId);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void Update(UserModel UserModel)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("USP_UpdateUser", con);
            cmd.Parameters.AddWithValue("@UserId", UserModel.UserId);
            cmd.Parameters.AddWithValue("@UserName", UserModel.UserName);
            cmd.Parameters.AddWithValue("@Password", UserModel.UserName);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        #endregion
    }
}
