﻿using Donne.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Donne.Dal
{
    public class PaymentRepository
    {
        #region Properties
        private readonly IConfigurationRoot configurationRoot;
        #endregion

        #region Constructor
        public PaymentRepository()
        {
            IConfigurationBuilder configurationBuilder = new ConfigurationBuilder().SetBasePath(Environment.CurrentDirectory).AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
            configurationRoot = configurationBuilder.Build();
        }
        #endregion

        #region Methods 

        public IEnumerable<PaymentModel> GetAllPayments()
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            List<PaymentModel> listPaymentModel = new List<PaymentModel>();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetAllPayments", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    PaymentModel Payment = new PaymentModel();
                    Payment.PaymentId = Convert.ToInt32(rdr["PaymentId"]);
                    Payment.CommandId = Convert.ToInt32(rdr["CommandId"]);
                    Payment.CustomerName = Convert.ToString(rdr["CustomerName"]);
                    Payment.FormOfPaymentId = Convert.ToInt32(rdr["FormOfPaymentId"]);
                    Payment.FormOfPaymentName = Convert.ToString(rdr["FormOfPaymentName"]);
                    Payment.DischargeDate = Convert.ToDateTime(rdr["DischargeDate"]);
                    Payment.Status = Convert.ToBoolean(rdr["Status"]);
                    Payment.Amount = Convert.ToDecimal(rdr["Amount"]);
                    listPaymentModel.Add(Payment);
                }
            }
            return listPaymentModel;
        }

        public PaymentModel GetById(int id)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            PaymentModel PaymentModel = new PaymentModel();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetByIdPayment", con);
                cmd.Parameters.AddWithValue("@PaymentId", id);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    PaymentModel.PaymentId = Convert.ToInt32(rdr["PaymentId"]);
                    PaymentModel.CommandId = Convert.ToInt32(rdr["CommandId"]);
                    PaymentModel.FormOfPaymentId = Convert.ToInt32(rdr["FormOfPaymentId"]);
                    PaymentModel.DischargeDate = Convert.ToDateTime(rdr["DischargeDate"]);
                    PaymentModel.Status = Convert.ToBoolean(rdr["Status"]);
                    PaymentModel.Amount = Convert.ToDecimal(rdr["Amount"]);
                }
            }
            return PaymentModel;
        }

        public void Insert(PaymentModel PaymentModel)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("USP_InsertPayment", con);
            cmd.Parameters.AddWithValue("@CommandId", PaymentModel.CommandId);
            cmd.Parameters.AddWithValue("@FormOfPaymentId", PaymentModel.FormOfPaymentId);
            cmd.Parameters.AddWithValue("@DischargeDate", PaymentModel.DischargeDate);
            cmd.Parameters.AddWithValue("@Status", PaymentModel.Status);
            cmd.Parameters.AddWithValue("@Amount", PaymentModel.Amount);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void Delete(int PaymentId)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("USP_DeletePayment", con);
            cmd.Parameters.AddWithValue("@PaymentId", PaymentId);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void Update(PaymentModel PaymentModel)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("USP_UpdatePayment", con);
            cmd.Parameters.AddWithValue("@PaymentId", PaymentModel.PaymentId);
            cmd.Parameters.AddWithValue("@CommandId", PaymentModel.CommandId);
            cmd.Parameters.AddWithValue("@FormOfPaymentId", PaymentModel.FormOfPaymentId);
            cmd.Parameters.AddWithValue("@DischargeDate", PaymentModel.DischargeDate);
            cmd.Parameters.AddWithValue("@Status", PaymentModel.Status);
            cmd.Parameters.AddWithValue("@Amount", PaymentModel.Amount);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        #endregion
    }
}
