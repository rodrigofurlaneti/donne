﻿using Donne.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Donne.Dal
{
    public class MonthlyBillingRepository
    {
        #region Properties
        private readonly IConfigurationRoot configurationRoot;
        #endregion

        #region Constructor
        public MonthlyBillingRepository()
        {
            IConfigurationBuilder configurationBuilder = new ConfigurationBuilder().SetBasePath(Environment.CurrentDirectory).AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
            configurationRoot = configurationBuilder.Build();
        }
        #endregion

        #region Methods 
        public List<MonthlyBillingModel> GetAllMonthlyBilling()
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            List<MonthlyBillingModel> listMonthlyBillingModel = new List<MonthlyBillingModel>();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetAllMonthlyBilling", con);
                cmd.Parameters.AddWithValue("@Month", DateTime.Now.Month);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    MonthlyBillingModel monthlyBillingModel = new MonthlyBillingModel();
                    monthlyBillingModel.DateNumber = Convert.ToDateTime(rdr["DateNumber"]);
                    monthlyBillingModel.DayNumber = Convert.ToInt32(rdr["DayNumber"]);
                    monthlyBillingModel.Amount = (rdr["Amount"].ToString() != String.Empty) ? Convert.ToDecimal(rdr["Amount"]) : 0;
                    listMonthlyBillingModel.Add(monthlyBillingModel);
                }
            }
            return listMonthlyBillingModel;
        }
        #endregion
    }
}
