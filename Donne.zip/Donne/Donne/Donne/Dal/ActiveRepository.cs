﻿using Donne.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Donne.Dal
{
    public class ActiveRepository
    {
        #region Properties
        private readonly IConfigurationRoot configurationRoot;
        #endregion

        #region Constructors
        public ActiveRepository()
        {
            IConfigurationBuilder configurationBuilder = new ConfigurationBuilder().SetBasePath(Environment.CurrentDirectory).AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
            configurationRoot = configurationBuilder.Build();
        }
        #endregion

        #region Methods 

        public IEnumerable<ActiveModel> GetAllActive()
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            List<ActiveModel> listActive = new List<ActiveModel>();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetAllActive", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    ActiveModel active = new ActiveModel();
                    active.ActiveId = Convert.ToInt32(rdr["ActiveId"]);
                    active.ActiveName = rdr["ActiveName"].ToString();
                    active.ActiveValue = Convert.ToDecimal(rdr["ActiveValue"]);
                    listActive.Add(active);
                }
            }
            return listActive;
        }

        public ActiveModel GetById(int id)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            ActiveModel active = new ActiveModel();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetByIdActive", con);
                cmd.Parameters.AddWithValue("@ActiveId", id);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    active.ActiveId = Convert.ToInt32(rdr["ActiveId"]);
                    active.ActiveName = rdr["ActiveName"].ToString();
                    active.ActiveValue = Convert.ToDecimal(rdr["ActiveValue"]);
                }
            }
            return active;
        }

        public void Insert(ActiveModel active)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("USP_InsertActive", con);
            cmd.Parameters.AddWithValue("@ActiveName", active.ActiveName);
            cmd.Parameters.AddWithValue("@ActiveValue", active.ActiveValue);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void Delete(int activeId)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("USP_DeleteActive", con);
            cmd.Parameters.AddWithValue("@ActiveId", activeId);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void Update(ActiveModel active)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("USP_UpdateActive", con);
            cmd.Parameters.AddWithValue("@ActiveId", active.ActiveId);
            cmd.Parameters.AddWithValue("@ActiveName", active.ActiveName);
            cmd.Parameters.AddWithValue("@ActiveValue", active.ActiveValue);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public ActiveModel GetActive()
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            ActiveModel active = new ActiveModel();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetActive", con);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    active.ActiveValue = Convert.ToDecimal(rdr["ActiveValue"]);
                }
            }
            return active;
        }
        #endregion
    }
}
