﻿using Donne.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Data;
using System.Data.SqlClient;

namespace Donne.Dal
{
	public class InventoryRepository
	{
        #region Properties
        private readonly IConfigurationRoot configurationRoot;
        #endregion

        #region Constructor
        public InventoryRepository()
        {
            IConfigurationBuilder configurationBuilder = new ConfigurationBuilder().SetBasePath(Environment.CurrentDirectory).AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
            configurationRoot = configurationBuilder.Build();
        }
        #endregion

        #region Methods 

        public InventoryModel GetInventory()
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            InventoryModel inventoryModel = new InventoryModel();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetInventory", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    inventoryModel.Inventory = Convert.ToDecimal(rdr["Inventory"]);
                    inventoryModel.Stock = Convert.ToDecimal(rdr["Stock"]);
                    inventoryModel.Profit = Convert.ToDecimal(rdr["Profit"]);

                }
            }
            return inventoryModel;
        }

		#endregion
	}
}
