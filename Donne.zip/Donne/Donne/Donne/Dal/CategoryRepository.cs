﻿using Donne.Models;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Donne.Dal
{
    public class CategoryRepository
    {
        #region Properties
        private readonly IConfigurationRoot configurationRoot;
        #endregion

        #region Constructors
        public CategoryRepository()
        {
            IConfigurationBuilder configurationBuilder = new ConfigurationBuilder().SetBasePath(Environment.CurrentDirectory).AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
            configurationRoot = configurationBuilder.Build();
        }
        #endregion

        #region Methods 

        public IEnumerable<CategoryModel> GetAllCategories()
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            List<CategoryModel> listCategoryModel = new List<CategoryModel>();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetAllCategories", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    CategoryModel category = new CategoryModel();
                    category.CategoryId = Convert.ToInt32(rdr["CategoryId"]);
                    category.CategoryName = rdr["CategoryName"].ToString();
                    listCategoryModel.Add(category);
                }
            }
            return listCategoryModel;
        }

        public CategoryModel GetById(int id)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            CategoryModel categoryModel = new CategoryModel();
            using (SqlConnection con = new SqlConnection(ConnectionString))
            {
                SqlCommand cmd = new SqlCommand("USP_GetByIdCategory", con);
                cmd.Parameters.AddWithValue("@CategoryId", id);
                con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    categoryModel.CategoryId = Convert.ToInt32(rdr["CategoryId"]);
                    categoryModel.CategoryName = rdr["CategoryName"].ToString();
                }
            }
            return categoryModel;
        }

        public void Insert(CategoryModel categoryModel)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("USP_InsertCategory", con);
            cmd.Parameters.AddWithValue("@CategoryName", categoryModel.CategoryName);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void Delete(int categoryId)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("USP_DeleteCategory", con);
            cmd.Parameters.AddWithValue("@CategoryId", categoryId);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        public void Update(CategoryModel categoryModel)
        {
            string ConnectionString = configurationRoot.GetConnectionString("LocalWebDatabase");
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand cmd = new SqlCommand("USP_UpdateCategory", con);
            cmd.Parameters.AddWithValue("@CategoryId", categoryModel.CategoryId);
            cmd.Parameters.AddWithValue("@CategoryName", categoryModel.CategoryName);
            con.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.ExecuteNonQuery();
            con.Close();
        }

        #endregion
    }
}
