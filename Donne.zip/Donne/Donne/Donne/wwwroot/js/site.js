﻿function formatarMoedaCostPrice() {
    var elemento = document.getElementById('CostPrice');
    var valor = elemento.value;
    valor = valor + '';
    valor = parseInt(valor.replace(/[\D]+/g, ''));
    valor = valor + '';
    valor = valor.replace(/([0-9]{2})$/g, ",$1");
    if (valor.length > 6) {
        valor = valor.replace(/([0-9]{3}),([0-9]{2}$)/g, ".$1,$2");
    }
    elemento.value = valor;
    if (valor == 'NaN') elemento.value = '';
}

function formatarMoedaSalePrice() {
    var elemento = document.getElementById('SalePrice');
    var valor = elemento.value;
    valor = valor + '';
    valor = parseInt(valor.replace(/[\D]+/g, ''));
    valor = valor + '';
    valor = valor.replace(/([0-9]{2})$/g, ",$1");
    if (valor.length > 6) {
        valor = valor.replace(/([0-9]{3}),([0-9]{2}$)/g, ".$1,$2");
    }
    elemento.value = valor;
    if (valor == 'NaN') elemento.value = '';
}

function calcular() {
    var costPrice = document.querySelector("#CostPrice");
    var salePrice = document.querySelector("#SalePrice");
    var quantityStock = document.querySelector("#QuantityStock");
    var totalValueCostOfInventory = parseFloat(costPrice.value.replace(',', '.')) * parseInt(quantityStock.value);
    var totalValueSaleStock = parseFloat(salePrice.value.replace(',', '.')) * parseInt(quantityStock.value);
    document.getElementById('TotalValueCostOfInventory').value = totalValueCostOfInventory.toLocaleString("pt-BR", {minimumFractionDigits: 2, maximumFractionDigits: 2 });
    document.getElementById('TotalValueSaleStock').value = totalValueSaleStock.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}