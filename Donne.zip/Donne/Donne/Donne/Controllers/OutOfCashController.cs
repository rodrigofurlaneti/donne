﻿using Donne.Dal;
using Donne.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

namespace Donne.Controllers
{
    public class OutOfCashController : Controller
    {
        #region Properties
        private readonly ILogger<OutOfCashController> _logger;
        #endregion
        #region Constructors
        public OutOfCashController(ILogger<OutOfCashController> logger)
        {
            _logger = logger;
        }
        #endregion
        #region Actions
        public IActionResult Index()
        {
            IEnumerable<OutOfCashModel> listOutOfCashModels = PopulateOutOfCash();
            ViewBag.TotalOutOfCash = PopulateTotalOutOfCash();
            return View(listOutOfCashModels);
        }
        public IActionResult Insert()
        {
            OutOfCashModel outOfCash = new OutOfCashModel();
            outOfCash.OutOfCashDate = DateTime.Now;
            return View(outOfCash);
        }

        [HttpPost]
        public IActionResult Insert(OutOfCashModel OutOfCashModel)
        {
            OutOfCashRepository dal = new OutOfCashRepository();
            dal.Insert(OutOfCashModel);
            ViewBag.Message = String.Format("Cadastrado uma nova saída de dinheiro com sucesso!");
            return View();
        }

        [HttpGet]
        public IActionResult Update(int id)
        {
            OutOfCashRepository dal = new OutOfCashRepository();
            OutOfCashModel OutOfCashModel = dal.GetById(id);
            return View(OutOfCashModel);
        }

        [HttpPost]
        public IActionResult Update(OutOfCashModel OutOfCashModel)
        {
            OutOfCashRepository dal = new OutOfCashRepository();
            dal.Update(OutOfCashModel);
            ViewBag.Message = String.Format("Atualizado a saída de dinheiro categoria com sucesso!");
            return View(OutOfCashModel);
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            OutOfCashRepository dal = new OutOfCashRepository();
            dal.Delete(id);
            return RedirectToAction("Index", "OutOfCash");
        }
        #endregion
        #region Methods
        private IEnumerable<OutOfCashModel> PopulateOutOfCash()
        {
            OutOfCashRepository dal = new OutOfCashRepository();
            return dal.GetAllOutOfCash();
        }
        private OutOfCashModel PopulateTotalOutOfCash()
        {
            OutOfCashRepository dal = new OutOfCashRepository();
            return dal.GetOutOfCash();
        }
        #endregion
    }
}
