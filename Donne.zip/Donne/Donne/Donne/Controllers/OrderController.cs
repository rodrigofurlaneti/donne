﻿using Donne.Dal;
using Donne.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

namespace Donne.Controllers
{
    public class OrderController : Controller
    {
        private readonly ILogger<OrderController> _logger;

        public OrderController(ILogger<OrderController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            OrderRepository dal = new OrderRepository();
            IEnumerable<OrderModel> listOrderModels = dal.GetAllOrders();
            return View(listOrderModels);
        }
        public IActionResult Insert()
        {
            ProductRepository dalProduct = new ProductRepository();
            IEnumerable<ProductModel> listProductModels = dalProduct.GetAllProducts();
            ViewBag.ProductId = listProductModels;
            CommandRepository dalCommand = new CommandRepository();
            IEnumerable<CommandModel> listCommandModels = dalCommand.GetAllCommands();
            ViewBag.CommandId = listCommandModels;
            return View();
        }

        [HttpPost]
        public IActionResult Insert(OrderModel orderModel)
        {
            OrderRepository dal = new OrderRepository();
            if (orderModel.Note == null) orderModel.Note = String.Empty;
            dal.Insert(orderModel);
            return RedirectToAction("Index", "Order");
        }

        [HttpGet]
        public IActionResult Update(int id)
        {
            OrderRepository dal = new OrderRepository();
            OrderModel orderModel = dal.GetById(id);
            ProductRepository dalProduct = new ProductRepository();
            IEnumerable<ProductModel> listProductModels = dalProduct.GetAllProducts();
            ViewBag.ProductId = listProductModels;
            CommandRepository dalCommand = new CommandRepository();
            IEnumerable<CommandModel> listCommandModels = dalCommand.GetAllCommands();
            ViewBag.CommandId = listCommandModels;
            return View(orderModel);
        }

        [HttpPost]
        public IActionResult Update(OrderModel orderModel)
        {
            OrderRepository dal = new OrderRepository();
            if (orderModel.Note == null) orderModel.Note = String.Empty;
            dal.Update(orderModel);
            return RedirectToAction("Index", "Order");
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            OrderRepository dal = new OrderRepository();
            dal.Delete(id);
            return RedirectToAction("Index", "Order");
        }
    }
}
