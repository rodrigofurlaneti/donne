﻿using Donne.Dal;
using Donne.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

namespace Donne.Controllers
{
    public class OrderController : Controller
    {
        private readonly ILogger<OrderController> _logger;

        public OrderController(ILogger<OrderController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            OrderRepository dal = new OrderRepository();
            IEnumerable<OrderModel> listOrderModels = dal.GetAllOrders();
            return View(listOrderModels);
        }
        public IActionResult Insert()
        {
            ViewBag.ProductId = PopulateProduct();
            ViewBag.CommandId = PopulateCommand();
            OrderModel orderModel = new OrderModel();
            orderModel.OrderDateAndTime = DateTime.Now;
            return View(orderModel);
        }

        [HttpPost]
        public IActionResult Insert(OrderModel orderModel)
        {
            ViewBag.ProductId = PopulateProduct();
            ViewBag.CommandId = PopulateCommand();
            OrderRepository dal = new OrderRepository();
            OrderModel order = new OrderModel();
            if (orderModel.Note == null) orderModel.Note = String.Empty;
            order = dal.Insert(orderModel);
            order = dal.GetById(order.OrderId);
            ViewBag.Message = String.Format("Pedido cadastrado na comanda cliente {0}.\\n Data e hora:{1}", order.CustomerName, order.OrderDateAndTime);
            return View(order);
        }

        [HttpGet]
        public IActionResult Update(int id)
        {
            OrderRepository dal = new OrderRepository();
            OrderModel orderModel = dal.GetById(id);
            ViewBag.ProductId = PopulateProduct();
            ViewBag.CommandId = PopulateCommand();
            return View(orderModel);
        }

        [HttpPost]
        public IActionResult Update(OrderModel orderModel)
        {
            OrderRepository dal = new OrderRepository();
            if (orderModel.Note == null) orderModel.Note = String.Empty;
            dal.Update(orderModel);
            ViewBag.ProductId = PopulateProduct();
            ViewBag.CommandId = PopulateCommand();
            ViewBag.Message = String.Format("Atualizado o produto com sucesso!");
            return View(orderModel);
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            OrderRepository dal = new OrderRepository();
            dal.Delete(id);
            return RedirectToAction("Index", "Order");
        }

		#region Methods
        private IEnumerable<ProductModel> PopulateProduct()
		{
            ProductRepository dalProduct = new ProductRepository();
            return dalProduct.GetAllProducts();
        }

        private IEnumerable<CommandModel> PopulateCommand()
		{
            CommandRepository dalCommand = new CommandRepository();
             return dalCommand.GetAllCommands();
        }
        #endregion
    }
}
