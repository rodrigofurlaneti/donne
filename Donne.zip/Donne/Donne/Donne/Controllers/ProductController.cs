﻿using Donne.Dal;
using Donne.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;

namespace Donne.Controllers
{
    public class ProductController : Controller
    {
        private readonly ILogger<ProductController> _logger;

        public ProductController(ILogger<ProductController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            ProductRepository dal = new ProductRepository();
            IEnumerable<ProductModel> listProductModels = dal.GetAllProducts();
            return View(listProductModels);
        }
        public IActionResult Insert()
        {
            var productModel = new ProductModel();
            CategoryRepository dal = new CategoryRepository();
            IEnumerable<CategoryModel> listCategoryModels = dal.GetAllCategories();
            ViewBag.CategoryId = listCategoryModels;
            return View(productModel);
        }

        [HttpPost]
        public IActionResult Insert(ProductModel ProductModel)
        {
            ProductRepository dal = new ProductRepository();
            dal.Insert(ProductModel);
            return RedirectToAction("Index", "Product");
        }

        [HttpGet]
        public IActionResult Update(int id)
        {
            ProductRepository dal = new ProductRepository();
            ProductModel productModel = dal.GetById(id);
            CategoryRepository dalCategory = new CategoryRepository();
            IEnumerable<CategoryModel> listCategoryModels = dalCategory.GetAllCategories();
            ViewBag.CategoryId = listCategoryModels;
            return View(productModel);
        }

        [HttpPost]
        public IActionResult Update(ProductModel productModel)
        {
            ProductRepository dal = new ProductRepository();
            dal.Update(productModel);
            return RedirectToAction("Index", "Product");
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            ProductRepository dal = new ProductRepository();
            dal.Delete(id);
            return RedirectToAction("Index", "Product");
        }
    }
}

