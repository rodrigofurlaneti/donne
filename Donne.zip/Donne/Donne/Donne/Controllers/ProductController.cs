﻿using Donne.Dal;
using Donne.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

namespace Donne.Controllers
{
    public class ProductController : Controller
    {
		#region Properties
		private readonly ILogger<ProductController> _logger;
		#endregion
		#region Constructors
		public ProductController(ILogger<ProductController> logger)
        {
            _logger = logger;
        }
		#endregion
		#region Actions
		public IActionResult Index()
        {
            IEnumerable<ProductModel> listProductModels = PopulateProduct();
            ViewBag.StatusId = PopulateId();
            ViewBag.NeedToPrintId = PopulateId();
            return View(listProductModels);
        }
        public IActionResult Insert()
        {
            var productModel = new ProductModel();
            ViewBag.CategoryId = PopulateCategory();
            ViewBag.StatusId = PopulateBool();
            ViewBag.NeedToPrintId = PopulateBool();
            return View(productModel);
        }

        [HttpPost]
        public IActionResult Insert(ProductModel productModel)
        {
            ProductRepository dal = new ProductRepository();
            dal.Insert(productModel);
            ViewBag.CategoryId = PopulateCategory();
            ViewBag.StatusId = PopulateBool();
            ViewBag.NeedToPrintId = PopulateBool();
            ViewBag.Message = String.Format("Cadastrado um novo produto com sucesso!");
            return View(productModel);
        }

        [HttpGet]
        public IActionResult Update(int id)
        {
            ProductRepository dal = new ProductRepository();
            ProductModel productModel = dal.GetById(id);
            ViewBag.CategoryId = PopulateCategory();
            productModel.SalePrice = Convert.ToDecimal(productModel.SalePrice.ToString("n2"));
            productModel.CostPrice = Convert.ToDecimal(productModel.CostPrice.ToString("n2"));
            productModel.TotalValueCostOfInventory = Convert.ToDecimal(productModel.TotalValueCostOfInventory.ToString("n2"));
            productModel.TotalValueSaleStock = Convert.ToDecimal(productModel.TotalValueSaleStock.ToString("n2"));
            ViewBag.StatusId = PopulateBool();
            ViewBag.NeedToPrintId = PopulateBool();
            return View(productModel);
        }

        [HttpPost]
        public IActionResult Update(ProductModel productModel)
        {
            ProductRepository dal = new ProductRepository();
            dal.Update(productModel);
            ViewBag.CategoryId = PopulateCategory();
            productModel.SalePrice = Convert.ToDecimal(productModel.SalePrice.ToString("n2"));
            productModel.CostPrice = Convert.ToDecimal(productModel.CostPrice.ToString("n2"));
            productModel.TotalValueCostOfInventory = Convert.ToDecimal(productModel.TotalValueCostOfInventory.ToString("n2"));
            productModel.TotalValueSaleStock = Convert.ToDecimal(productModel.TotalValueSaleStock.ToString("n2"));
            ViewBag.StatusId = PopulateBool();
            ViewBag.NeedToPrintId = PopulateBool();
            ViewBag.Message = String.Format("Atualizado o produto com sucesso!");
            return View(productModel);
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            ProductRepository dal = new ProductRepository();
            dal.Delete(id);
            return RedirectToAction("Index", "Product");
        }
		#endregion
		#region Methods
		private IEnumerable<ProductModel> PopulateProduct()
		{
            ProductRepository dal = new ProductRepository();
            return dal.GetAllProducts();
        }
        private IEnumerable<CategoryModel> PopulateCategory()
		{
            CategoryRepository dal = new CategoryRepository();
            return dal.GetAllCategories();
        }
        private List<SelectListItem> PopulateId()
		{
            return new List<SelectListItem>{ new SelectListItem{ Text="Sim", Value = "1" },
                                             new SelectListItem{ Text="Não", Value = "0" }};
        }
        private List<SelectListItem> PopulateBool()
        {
            return new List<SelectListItem>{ new SelectListItem{ Text="Não", Value = "false" },
                                             new SelectListItem{ Text="Sim", Value = "true" }};
        }
        #endregion
    }
}

