﻿using Donne.Dal;
using Donne.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

namespace Donne.Controllers
{
    public class ProductController : Controller
    {
        private readonly ILogger<ProductController> _logger;

        public ProductController(ILogger<ProductController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            ProductRepository dal = new ProductRepository();
            IEnumerable<ProductModel> listProductModels = dal.GetAllProducts();
            ViewBag.StatusId = new List<SelectListItem>{ new SelectListItem{ Text="Sim", Value = "1" },
                                                       new SelectListItem{ Text="Não", Value = "0" }};
            return View(listProductModels);
        }
        public IActionResult Insert()
        {
            var productModel = new ProductModel();
            CategoryRepository dal = new CategoryRepository();
            IEnumerable<CategoryModel> listCategoryModels = dal.GetAllCategories();
            ViewBag.CategoryId = listCategoryModels;
            ViewBag.StatusId = new List<SelectListItem>{ new SelectListItem{ Text="Não", Value = "false" },
                                                        new SelectListItem{ Text="Sim", Value = "true" }};
            return View(productModel);
        }

        [HttpPost]
        public IActionResult Insert(ProductModel productModel)
        {
            ProductRepository dal = new ProductRepository();
            dal.Insert(productModel);
            return RedirectToAction("Index", "Product");
        }

        [HttpGet]
        public IActionResult Update(int id)
        {
            ProductRepository dal = new ProductRepository();
            ProductModel productModel = dal.GetById(id);
            CategoryRepository dalCategory = new CategoryRepository();
            IEnumerable<CategoryModel> listCategoryModels = dalCategory.GetAllCategories();
            ViewBag.CategoryId = listCategoryModels;
            productModel.SalePrice = Convert.ToDecimal(productModel.SalePrice.ToString("n2"));
            productModel.CostPrice = Convert.ToDecimal(productModel.CostPrice.ToString("n2"));
            productModel.TotalValueCostOfInventory = Convert.ToDecimal(productModel.TotalValueCostOfInventory.ToString("n2"));
            productModel.TotalValueSaleStock = Convert.ToDecimal(productModel.TotalValueSaleStock.ToString("n2"));
            ViewBag.StatusId = new List<SelectListItem>{ new SelectListItem{ Text="Não", Value = "false" },
                                                        new SelectListItem{ Text="Sim", Value = "true" }};
            return View(productModel);
        }

        [HttpPost]
        public IActionResult Update(ProductModel productModel)
        {
            ProductRepository dal = new ProductRepository();
            dal.Update(productModel);
            return RedirectToAction("Index", "Product");
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            ProductRepository dal = new ProductRepository();
            dal.Delete(id);
            return RedirectToAction("Index", "Product");
        }
    }
}

