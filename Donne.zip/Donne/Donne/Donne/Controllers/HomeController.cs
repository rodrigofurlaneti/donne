﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Donne.Controllers
{
    public class HomeController : Controller
    {
		#region Properties
		private readonly ILogger<HomeController> _logger;
		#endregion
		#region Constructors
		public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }
		#endregion
		#region Actions
		public IActionResult Index()
        {
            return View();
        }
		#endregion
	}
}
