﻿using Donne.Dal;
using Donne.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using Newtonsoft.Json;

namespace Donne.Controllers
{
    public class HomeController : Controller
    {
		#region Properties
		private readonly ILogger<HomeController> _logger;

        #endregion
        #region Constructors
        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public object JsonConvert { get; private set; }
        #endregion
        #region Actions
        public IActionResult Index()
        {
            return View();
        }
        
        [HttpPost]
        public IActionResult Login(UserModel user)
        {
            UserRepository dal = new UserRepository();
            var ret = dal.GetByLogin(user);
            if(ret.UserId != 0)
            {
                HttpContext.Session.SetString("UserId", ret.UserId.ToString());
                ViewBag.User = HttpContext.Session.GetString("UserId");  
                ViewBag.Message = String.Format("Ok");
            }
            else
            {
                ViewBag.MessageErro = String.Format("Usuário ou senha inválidos");
            }
            return View();
        }
        #endregion
    }
}
