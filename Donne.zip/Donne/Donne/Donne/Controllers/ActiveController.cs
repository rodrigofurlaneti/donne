﻿using Donne.Dal;
using Donne.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

namespace Donne.Controllers
{
    public class ActiveController : Controller
    {
        #region Properties
        private readonly ILogger<ActiveController> _logger;
        #endregion
        #region Constructors
        public ActiveController(ILogger<ActiveController> logger)
        {
            _logger = logger;
        }
        #endregion
        #region Actions
        public IActionResult Index()
        {
            IEnumerable<ActiveModel> listActive = PopulateActive();
            ActiveRepository dal = new ActiveRepository();
            ActiveModel active = dal.GetActive();
            ViewBag.TotalActiveValue = active.ActiveValue;
            return View(listActive);
        }
        public IActionResult IndexJson()
        {
            IEnumerable<ActiveModel> listActive = PopulateActive();
            return Json(listActive);
        }
        public IActionResult Insert()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Insert(ActiveModel active)
        {
            ActiveRepository dal = new ActiveRepository();
            dal.Insert(active);
            ViewBag.Message = String.Format("Cadastrado um novo ativo com sucesso!");
            return View();
        }

        [HttpGet]
        public IActionResult Update(int id)
        {
            ActiveRepository dal = new ActiveRepository();
            ActiveModel active = dal.GetById(id);
            return View(active);
        }

        [HttpPost]
        public IActionResult Update(ActiveModel active)
        {
            ActiveRepository dal = new ActiveRepository();
            dal.Update(active);
            ViewBag.Message = String.Format("Atualizado o ativo com sucesso!");
            return View(active);
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            ActiveRepository dal = new ActiveRepository();
            dal.Delete(id);
            return RedirectToAction("Index", "Active");
        }
        #endregion
        #region Methods
        private IEnumerable<ActiveModel> PopulateActive()
        {
            ActiveRepository dal = new ActiveRepository();
            return dal.GetAllActive();
        }
        #endregion
    }
}
