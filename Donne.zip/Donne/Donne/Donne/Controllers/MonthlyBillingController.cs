﻿using Donne.Dal;
using Donne.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace Donne.Controllers
{
    public class MonthlyBillingController : Controller
    {
        #region Actions

        public IActionResult Index()
        {
			MonthlyBillingRepository dal = new MonthlyBillingRepository();
			List<MonthlyBillingModel> listRenevuesModels = dal.GetAllMonthlyBilling();
			return View(listRenevuesModels);
		}

		public IActionResult IndexJson()
		{
			MonthlyBillingRepository dal = new MonthlyBillingRepository();
			List<MonthlyBillingModel> listRenevuesModels = dal.GetAllMonthlyBilling();
			return Json(listRenevuesModels);
		}

		#endregion
	}
}
