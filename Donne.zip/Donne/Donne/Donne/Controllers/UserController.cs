﻿using Donne.Dal;
using Donne.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

namespace Donne.Controllers
{
    public class UserController : Controller
    {
        #region Properties
        private readonly ILogger<UserController> _logger;
        #endregion
        #region Constructors
        public UserController(ILogger<UserController> logger)
        {
            _logger = logger;
        }
        #endregion
        #region Actions
        public IActionResult Index()
        {
            IEnumerable<UserModel> listUserModels = PopulateUser();
            return View(listUserModels);
        }
        public IActionResult Insert()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Insert(UserModel UserModel)
        {
            UserRepository dal = new UserRepository();
            dal.Insert(UserModel);
            ViewBag.Message = String.Format("Cadastrado uma nova categoria com sucesso!");
            return View();
        }

        [HttpGet]
        public IActionResult Update(int id)
        {
            UserRepository dal = new UserRepository();
            UserModel UserModel = dal.GetById(id);
            return View(UserModel);
        }

        [HttpPost]
        public IActionResult Update(UserModel UserModel)
        {
            UserRepository dal = new UserRepository();
            dal.Update(UserModel);
            ViewBag.Message = String.Format("Atualizado a categoria com sucesso!");
            return View(UserModel);
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            UserRepository dal = new UserRepository();
            dal.Delete(id);
            return RedirectToAction("Index", "User");
        }
        #endregion
        #region Methods
        private IEnumerable<UserModel> PopulateUser()
        {
            UserRepository dal = new UserRepository();
            return dal.GetAllUser();
        }
        #endregion
    }
}
