﻿using Donne.Dal;
using Donne.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace Donne.Controllers
{
	public class InventoryController : Controller
	{
		#region Actions
		public IActionResult Index()
		{
			InventoryRepository dal = new InventoryRepository();
			InventoryModel inventoryModel = dal.GetInventory();
			ViewBag.CategoryId = PopulateCategory();
			return View(inventoryModel);
		}
		public IActionResult IndexJson()
		{
			InventoryRepository dal = new InventoryRepository();
			InventoryModel inventoryModel = dal.GetInventory();
			return Json(inventoryModel);
		}

		[HttpPost]
        public IActionResult Insert(InventoryModel inventoryModel)
        {
            InventoryModel inventory = PopulateInventoryByCategory(inventoryModel);
            return View(inventory);
        }

		[HttpPost]
		public IActionResult InsertJson(string id)
		{
			InventoryRepository dal = new InventoryRepository();
			InventoryModel inventoryModel = dal.GetInventoryByCategory(Convert.ToInt32(id));
			return Json(inventoryModel);
		}

		#endregion
		#region Methods
		private IEnumerable<CategoryModel> PopulateCategory()
        {
            CategoryRepository dal = new CategoryRepository();
            return dal.GetAllCategories();
        }
        private InventoryModel PopulateInventoryByCategory(InventoryModel inventoryModel)
		{
            InventoryRepository dal = new InventoryRepository();
            return dal.GetInventoryByCategory(inventoryModel.CategoryId);
        }
        #endregion
    }
}
