﻿using Donne.Dal;
using Donne.Models;
using Microsoft.AspNetCore.Mvc;

namespace Donne.Controllers
{
	public class InventoryController : Controller
	{
		public IActionResult Index()
		{
			InventoryRepository dal = new InventoryRepository();
			InventoryModel inventoryModel = dal.GetInventory();
			return View(inventoryModel);
		}
	}
}
