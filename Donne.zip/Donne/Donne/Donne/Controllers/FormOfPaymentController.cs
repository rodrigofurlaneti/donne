﻿using Donne.Dal;
using Donne.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

namespace Donne.Controllers
{
    public class FormOfPaymentController : Controller
    {
		#region Properties
		private readonly ILogger<FormOfPaymentController> _logger;
		#endregion
		#region Constructors
		public FormOfPaymentController(ILogger<FormOfPaymentController> logger)
        {
            _logger = logger;
        }
		#endregion
		#region Actions
		public IActionResult Index()
        {
            FormOfPaymentRepository dal = new FormOfPaymentRepository();
            IEnumerable<FormOfPaymentModel> listFormOfPaymentModels = dal.GetAllFormOfPayments();
            ViewBag.DebitCardTotal = PopulateDebitCardTotal();
            ViewBag.CreditCardTotal = PopulateCreditCardTotal();
            ViewBag.TotalMoney = PopulateTotalMoney();
            ViewBag.TotalPix = PopulateTotalPix();
            return View(listFormOfPaymentModels);
        }
        public IActionResult Insert()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Insert(FormOfPaymentModel FormOfPaymentModel)
        {
            FormOfPaymentRepository dal = new FormOfPaymentRepository();
            dal.Insert(FormOfPaymentModel);
            ViewBag.Message = String.Format("Cadastrado uma nova forma de pagamento com sucesso!");
            return View();
        }

        [HttpGet]
        public IActionResult Update(int id)
        {
            FormOfPaymentRepository dal = new FormOfPaymentRepository();
            FormOfPaymentModel FormOfPaymentModel = dal.GetById(id);
            return View(FormOfPaymentModel);
        }

        [HttpPost]
        public IActionResult Update(FormOfPaymentModel FormOfPaymentModel)
        {
            FormOfPaymentRepository dal = new FormOfPaymentRepository();
            dal.Update(FormOfPaymentModel);
            ViewBag.Message = String.Format("Atualizado a forma de pagamento com sucesso!");
            return View(FormOfPaymentModel);
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            FormOfPaymentRepository dal = new FormOfPaymentRepository();
            dal.Delete(id);
            return RedirectToAction("Index", "FormOfPayment");
        }
        public IActionResult IndexJson()
        {
            FormOfPaymentRepository dal = new FormOfPaymentRepository();
            FormOfPaymentModel debit = dal.GetDebitCardTotal();
            FormOfPaymentModel credit = dal.GetCreditCardTotal();
            FormOfPaymentModel money = dal.GetTotalMoney();
            FormOfPaymentModel pix = dal.GetTotalPix();
            FormOfPaymentModel list = new FormOfPaymentModel();
            list.FormOfPaymentValueDebit = debit.FormOfPaymentValueDebit;
            list.FormOfPaymentValueCredit = credit.FormOfPaymentValueCredit;
            list.FormOfPaymentValueMoney = money.FormOfPaymentValueMoney;
            list.FormOfPaymentValuePix = pix.FormOfPaymentValuePix;
            return Json(list);
        }
        #endregion
        #region
        private FormOfPaymentModel PopulateDebitCardTotal()
        {
            FormOfPaymentRepository dal = new FormOfPaymentRepository();
            return dal.GetDebitCardTotal();
        }
        private FormOfPaymentModel PopulateCreditCardTotal()
        {
            FormOfPaymentRepository dal = new FormOfPaymentRepository();
            return dal.GetCreditCardTotal();
        }
        private FormOfPaymentModel PopulateTotalMoney()
        {
            FormOfPaymentRepository dal = new FormOfPaymentRepository();
            return dal.GetTotalMoney();
        }
        private FormOfPaymentModel PopulateTotalPix()
        {
            FormOfPaymentRepository dal = new FormOfPaymentRepository();
            return dal.GetTotalPix();
        }
        #endregion
    }
}
