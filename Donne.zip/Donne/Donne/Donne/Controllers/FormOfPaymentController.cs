﻿using Donne.Dal;
using Donne.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;

namespace Donne.Controllers
{
    public class FormOfPaymentController : Controller
    {
        private readonly ILogger<FormOfPaymentController> _logger;

        public FormOfPaymentController(ILogger<FormOfPaymentController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            FormOfPaymentRepository dal = new FormOfPaymentRepository();
            IEnumerable<FormOfPaymentModel> listFormOfPaymentModels = dal.GetAllFormOfPayments();
            return View(listFormOfPaymentModels);
        }
        public IActionResult Insert()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Insert(FormOfPaymentModel FormOfPaymentModel)
        {
            FormOfPaymentRepository dal = new FormOfPaymentRepository();
            dal.Insert(FormOfPaymentModel);
            return RedirectToAction("Index", "FormOfPayment");
        }

        [HttpGet]
        public IActionResult Update(int id)
        {
            FormOfPaymentRepository dal = new FormOfPaymentRepository();
            FormOfPaymentModel FormOfPaymentModel = dal.GetById(id);
            return View(FormOfPaymentModel);
        }

        [HttpPost]
        public IActionResult Update(FormOfPaymentModel FormOfPaymentModel)
        {
            FormOfPaymentRepository dal = new FormOfPaymentRepository();
            dal.Update(FormOfPaymentModel);
            return RedirectToAction("Index", "FormOfPayment");
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            FormOfPaymentRepository dal = new FormOfPaymentRepository();
            dal.Delete(id);
            return RedirectToAction("Index", "FormOfPayment");
        }
    }
}
