﻿using Donne.Dal;
using Donne.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;

namespace Donne.Controllers
{
    public class PaymentController : Controller
    {
        private readonly ILogger<PaymentController> _logger;

        public PaymentController(ILogger<PaymentController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            PaymentRepository dal = new PaymentRepository();
            IEnumerable<PaymentModel> listPaymentModels = dal.GetAllPayments();
            return View(listPaymentModels);
        }
        public IActionResult Insert()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Insert(PaymentModel PaymentModel)
        {
            PaymentRepository dal = new PaymentRepository();
            dal.Insert(PaymentModel);
            return RedirectToAction("Index", "Payment");
        }

        [HttpGet]
        public IActionResult Update(int id)
        {
            PaymentRepository dal = new PaymentRepository();
            PaymentModel PaymentModel = dal.GetById(id);
            return View(PaymentModel);
        }

        [HttpPost]
        public IActionResult Update(PaymentModel PaymentModel)
        {
            PaymentRepository dal = new PaymentRepository();
            dal.Update(PaymentModel);
            return RedirectToAction("Index", "Payment");
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            PaymentRepository dal = new PaymentRepository();
            dal.Delete(id);
            return RedirectToAction("Index", "Payment");
        }
    }
}
