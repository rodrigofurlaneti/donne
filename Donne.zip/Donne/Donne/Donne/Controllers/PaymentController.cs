﻿using Donne.Dal;
using Donne.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

namespace Donne.Controllers
{
    public class PaymentController : Controller
    {
        private readonly ILogger<PaymentController> _logger;

        public PaymentController(ILogger<PaymentController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            PaymentRepository dal = new PaymentRepository();
            IEnumerable<PaymentModel> listPaymentModels = dal.GetAllPayments();
            return View(listPaymentModels);
        }
        public IActionResult Insert()
        {
            CommandRepository dalCommand = new CommandRepository();
            IEnumerable<CommandModel> listCommandModels = dalCommand.GetAllActiveCommands();
            ViewBag.CommandId = listCommandModels;
            FormOfPaymentRepository dalFormOfPayment = new FormOfPaymentRepository();
            IEnumerable<FormOfPaymentModel> listFormOfPaymentModels = dalFormOfPayment.GetAllFormOfPayments();
            ViewBag.FormOfPaymentId = listFormOfPaymentModels;
            PaymentModel paymentModel = new PaymentModel();
            paymentModel.DischargeDate = System.DateTime.Now;
            paymentModel.Status = true;
            ViewBag.Status = new List<SelectListItem>{ new SelectListItem{ Text="Não", Value = "false" },
                                                       new SelectListItem{ Text="Sim", Value = "true" }};
            return View(paymentModel);
        }

        [HttpPost]
        public IActionResult Insert(PaymentModel paymentModel)
        {
            PaymentRepository dal = new PaymentRepository();
            dal.Insert(paymentModel);
            CommandRepository dalCommand = new CommandRepository();
            IEnumerable<CommandModel> listCommandModels = dalCommand.GetAllActiveCommands();
            ViewBag.CommandId = listCommandModels;
            FormOfPaymentRepository dalFormOfPayment = new FormOfPaymentRepository();
            IEnumerable<FormOfPaymentModel> listFormOfPaymentModels = dalFormOfPayment.GetAllFormOfPayments();
            ViewBag.FormOfPaymentId = listFormOfPaymentModels;
            ViewBag.Status = new List<SelectListItem>{ new SelectListItem{ Text="Não", Value = "false" },
                                                       new SelectListItem{ Text="Sim", Value = "true" }};
            ViewBag.Message = String.Format("Cadastrado uma novo pagamento com sucesso!");
            return View(paymentModel);
        }

        [HttpGet]
        public IActionResult Update(int id)
        {
            PaymentRepository dal = new PaymentRepository();
            PaymentModel PaymentModel = dal.GetById(id);
            CommandRepository dalCommand = new CommandRepository();
            IEnumerable<CommandModel> listCommandModels = dalCommand.GetAllActiveCommands();
            ViewBag.CommandId = listCommandModels;
            FormOfPaymentRepository dalFormOfPayment = new FormOfPaymentRepository();
            IEnumerable<FormOfPaymentModel> listFormOfPaymentModels = dalFormOfPayment.GetAllFormOfPayments();
            ViewBag.FormOfPaymentId = listFormOfPaymentModels;
            ViewBag.Status = new List<SelectListItem>{ new SelectListItem{ Text="Não", Value = "false" },
                                                       new SelectListItem{ Text="Sim", Value = "true" }};
            return View(PaymentModel);
        }

        [HttpPost]
        public IActionResult Update(PaymentModel PaymentModel)
        {
            PaymentRepository dal = new PaymentRepository();
            dal.Update(PaymentModel);
            return RedirectToAction("Index", "Payment");
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            PaymentRepository dal = new PaymentRepository();
            dal.Delete(id);
            return RedirectToAction("Index", "Payment");
        }
    }
}
