﻿using Donne.Dal;
using Donne.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

namespace Donne.Controllers
{
    public class PaymentController : Controller
    {
		#region Properties
		private readonly ILogger<PaymentController> _logger;
		#endregion
		#region Constructors
		public PaymentController(ILogger<PaymentController> logger)
        {
            _logger = logger;
        }
		#endregion
		#region Actions
		public IActionResult Index()
        {
            IEnumerable<PaymentModel> listPaymentModels = PopulatePayment();
            return View(listPaymentModels);
        }
        public IActionResult Insert()
        {
            ViewBag.CommandId = PopulateActiveCommand();
            ViewBag.FormOfPaymentId = PopulateFormOfPayment();
            PaymentModel paymentModel = new PaymentModel();
            paymentModel.DischargeDate = System.DateTime.Now;
            paymentModel.Status = true;
            ViewBag.Status = PopulateBool();
            return View(paymentModel);
        }

        [HttpPost]
        public IActionResult Insert(PaymentModel paymentModel)
        {
            PaymentRepository dal = new PaymentRepository();
            dal.Insert(paymentModel);
            ViewBag.CommandId = PopulateActiveCommand();
            ViewBag.FormOfPaymentId = PopulateFormOfPayment();
            ViewBag.Status = PopulateBool();
            ViewBag.Message = String.Format("Cadastrado uma novo pagamento com sucesso!");
            return View(paymentModel);
        }

        [HttpGet]
        public IActionResult Update(int id)
        {
            PaymentRepository dal = new PaymentRepository();
            PaymentModel PaymentModel = dal.GetById(id);
            ViewBag.CommandId = PopulateActiveCommand();
            ViewBag.FormOfPaymentId = PopulateFormOfPayment();
            ViewBag.Status = PopulateBool();
            return View(PaymentModel);
        }

        [HttpPost]
        public IActionResult Update(PaymentModel paymentModel)
        {
            PaymentRepository dal = new PaymentRepository();
            dal.Update(paymentModel);
            ViewBag.Message = String.Format("Atualizado o pagamento com sucesso!");
            return View(paymentModel);
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            PaymentRepository dal = new PaymentRepository();
            dal.Delete(id);
            return RedirectToAction("Index", "Payment");
        }
		#endregion
		#region Methods
		private IEnumerable<PaymentModel> PopulatePayment()
		{
            PaymentRepository dal = new PaymentRepository();
            return dal.GetAllPayments();
		}
        private IEnumerable<CommandModel> PopulateActiveCommand()
		{
            CommandRepository dalCommand = new CommandRepository();
            return dalCommand.GetAllActiveCommands();
        }
        private IEnumerable<FormOfPaymentModel> PopulateFormOfPayment()
		{
            FormOfPaymentRepository dalFormOfPayment = new FormOfPaymentRepository();
            return dalFormOfPayment.GetAllFormOfPayments();
        }
        private List<SelectListItem> PopulateBool()
		{
            return new List<SelectListItem>{ new SelectListItem{ Text="Não", Value = "false" },
                                             new SelectListItem{ Text="Sim", Value = "true" }};
        }
        #endregion
    }
}
