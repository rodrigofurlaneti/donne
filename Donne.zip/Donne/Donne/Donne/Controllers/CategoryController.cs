﻿using Donne.Dal;
using Donne.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;

namespace Donne.Controllers
{
    public class CategoryController : Controller
    {
        private readonly ILogger<CategoryController> _logger;

        public CategoryController(ILogger<CategoryController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            CategoryRepository dal = new CategoryRepository();
            IEnumerable<CategoryModel> listCategoryModels = dal.GetAllCategories();
            return View(listCategoryModels);
        }
        public IActionResult Insert()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Insert(CategoryModel categoryModel)
        {
            CategoryRepository dal = new CategoryRepository();
            dal.Insert(categoryModel);
            return RedirectToAction("Index", "Category");
        }

        [HttpGet]
        public IActionResult Update(int id)
        {
            CategoryRepository dal = new CategoryRepository();
            CategoryModel categoryModel = dal.GetById(id);
            return View(categoryModel);
        }

        [HttpPost]
        public IActionResult Update(CategoryModel categoryModel)
        {
            CategoryRepository dal = new CategoryRepository();
            dal.Update(categoryModel);
            return RedirectToAction("Index", "Category");
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            CategoryRepository dal = new CategoryRepository();
            dal.Delete(id);
            return RedirectToAction("Index","Category");
        }
    }
}
