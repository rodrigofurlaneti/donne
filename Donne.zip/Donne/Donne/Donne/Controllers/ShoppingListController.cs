﻿using Donne.Dal;
using Donne.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Donne.Controllers
{
	public class ShoppingListController : Controller
	{
		#region Properties
		private readonly ILogger<ShoppingListController> _logger;
		#endregion
		#region Constructors
		public ShoppingListController(ILogger<ShoppingListController> logger)
		{
			_logger = logger;

		}
		#endregion
		#region Actions
		public IActionResult Index()
		{
			ShoppingListRepository dal = new ShoppingListRepository();
			IEnumerable<ShoppingListModel> shoppingListModels = dal.GetAllShoppingList();
			return View(shoppingListModels);
		}
		#endregion
	}
}
