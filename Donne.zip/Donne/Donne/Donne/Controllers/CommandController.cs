﻿using Donne.Dal;
using Donne.Dal.Customer;
using Donne.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

namespace Donne.Controllers
{
    public class CommandController : Controller
    {
        private readonly ILogger<CommandController> _logger;

        public CommandController(ILogger<CommandController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            IEnumerable<CommandModel> listCommandModels = PopulateCommand();
            foreach (var item in listCommandModels)
            {
                if(item.EndDateAndTime.ToString() == "01/01/1900 00:00:00")
                {
                    item.EndDateAndTime = null;
                }
            }
            return View(listCommandModels);
        }
        public IActionResult Insert()
        {
            var commandModel = new CommandModel();
            commandModel.StartDateAndTime = DateTime.Now;
            ViewBag.CustomerId = PopulateCustomer();
            ViewBag.PaidOut = PopulatePaidOut();
            return View(commandModel);
        }

        [HttpPost]
        public IActionResult Insert(CommandModel commandModel)
        {
            CommandRepository dal = new CommandRepository();
            dal.Insert(commandModel);
            ViewBag.CustomerId = PopulateCustomer();
            ViewBag.PaidOut = PopulatePaidOut();
            ViewBag.Message = String.Format("Cadastrado uma nova comanda com sucesso!");
            return View(commandModel);
        }

        [HttpGet]
        public IActionResult Update(int id)
        {
            CommandRepository dal = new CommandRepository();
            CommandModel commandModel = dal.GetById(id);
            if (commandModel.EndDateAndTime.ToString() == "01/01/1900 00:00:00")
            {
                commandModel.EndDateAndTime = null;
            }
            ViewBag.CustomerId = PopulateCustomer();
            ViewBag.PaidOut = PopulatePaidOut();
            return View(commandModel);
        }

        [HttpPost]
        public IActionResult Update(CommandModel commandModel)
        {
            CommandRepository dal = new CommandRepository();
            if (commandModel.EndDateAndTime == null)
            {
                commandModel.EndDateAndTime = Convert.ToDateTime("01/01/1900 00:00:00");
            }
            dal.Update(commandModel);
            if (commandModel.EndDateAndTime.ToString() == "01/01/1900 00:00:00")
            {
                commandModel.EndDateAndTime = null;
            }
            ViewBag.CustomerId = PopulateCustomer();
            ViewBag.PaidOut = PopulatePaidOut();
            ViewBag.Message = String.Format("Atualizado a comanda com sucesso!");
            return View(commandModel);
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            CommandRepository dal = new CommandRepository();
            dal.Delete(id);
            return RedirectToAction("Index", "Command");
        }

		#region Methods
        private IEnumerable<CommandModel> PopulateCommand()
		{
            CommandRepository dal = new CommandRepository();
            return dal.GetAllCommands();
        }

        private IEnumerable<CustomerModel> PopulateCustomer()
		{
            CustomerRepository dalCustomer = new CustomerRepository();
             return dalCustomer.GetAllCustomers();
        }
        private List<SelectListItem> PopulatePaidOut()
		{
            return new List<SelectListItem>{ new SelectListItem{ Text="Não", Value = "false" },
                                             new SelectListItem{ Text="Sim", Value = "true" }};
        }
        #endregion
    }
}
