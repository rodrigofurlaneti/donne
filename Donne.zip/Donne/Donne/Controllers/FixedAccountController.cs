﻿using Donne.Dal;
using Donne.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace Donne.Controllers
{
    public class FixedAccountController : Controller
    {
        #region Actions
        public IActionResult Index()
        {
            IEnumerable<FixedAccountModel> listFixedAccount = PopulateFixedAccount();
            ViewBag.TotalFixedAccountMonth = PopulateTotalFixedAccountMonth();
            ViewBag.TotalFixedAccountWeek = PopulateTotalFixedAccountWeek();
            ViewBag.TotalFixedAccountDay = PopulateTotalFixedAccountDay();
            ViewBag.MetaCemTotalFixedAccountMonth = PopulateMetaCemTotalFixedAccountMonth();
            ViewBag.MetaCemTotalFixedAccountWeek = PopulateMetaCemTotalFixedAccountWeek();
            ViewBag.MetaCemTotalFixedAccountDay = PopulateMetaCemTotalFixedAccountDay();
            ViewBag.MetaCinquentaTotalFixedAccountMonth = PopulateMetaCinquentaTotalFixedAccountMonth();
            ViewBag.MetaCinquentaTotalFixedAccountWeek = PopulateMetaCinquentaTotalFixedAccountWeek();
            ViewBag.MetaCinquentaTotalFixedAccountDay = PopulateMetaCinquentaTotalFixedAccountDay();
            return View(listFixedAccount);
        }
        public IActionResult Insert()
        {
            var fixedAccountModel = new FixedAccountModel();
            return View(fixedAccountModel);
        }

        [HttpPost]
        public IActionResult Insert(FixedAccountModel fixedAccountModel)
        {
            FixedAccountRepository dal = new FixedAccountRepository();
            dal.Insert(fixedAccountModel);
            ViewBag.Message = String.Format("Cadastrado uma nova conta fixa com sucesso!");
            return View(fixedAccountModel);
        }

        [HttpGet]
        public IActionResult Update(int id)
        {
            FixedAccountRepository dal = new FixedAccountRepository();
            FixedAccountModel fixedAccount = dal.GetById(id);
            fixedAccount.FixedAccountMonth = Convert.ToDecimal(fixedAccount.FixedAccountMonth.ToString("n2"));
            fixedAccount.FixedAccountWeek = Convert.ToDecimal(fixedAccount.FixedAccountWeek.ToString("n2"));
            fixedAccount.FixedAccountDay = Convert.ToDecimal(fixedAccount.FixedAccountDay.ToString("n2"));
            return View(fixedAccount);
        }

        [HttpPost]
        public IActionResult Update(FixedAccountModel fixedAccount)
        {
            FixedAccountRepository dal = new FixedAccountRepository();
            dal.Update(fixedAccount);
            fixedAccount.FixedAccountMonth = Convert.ToDecimal(fixedAccount.FixedAccountMonth.ToString("n2"));
            fixedAccount.FixedAccountWeek = Convert.ToDecimal(fixedAccount.FixedAccountWeek.ToString("n2"));
            fixedAccount.FixedAccountDay = Convert.ToDecimal(fixedAccount.FixedAccountDay.ToString("n2"));
            ViewBag.Message = String.Format("Atualizado a conta fixa com sucesso!");
            return View(fixedAccount);
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            FixedAccountRepository dal = new FixedAccountRepository();
            dal.Delete(id);
            return RedirectToAction("Index", "FixedAccount");
        }
        #endregion
        #region Methods
        private IEnumerable<FixedAccountModel> PopulateFixedAccount()
        {
            FixedAccountRepository dal = new FixedAccountRepository();
            return dal.GetAllFixedAccount();
        }
        private FixedAccountModel PopulateTotalFixedAccountMonth()
        {
            FixedAccountRepository dal = new FixedAccountRepository();
            return dal.GetFixedAccountMonth();
        }

        private FixedAccountModel PopulateTotalFixedAccountWeek()
        {
            FixedAccountRepository dal = new FixedAccountRepository();
            return dal.GetFixedAccountWeek();
        }

        private FixedAccountModel PopulateTotalFixedAccountDay()
        {
            FixedAccountRepository dal = new FixedAccountRepository();
            return dal.GetFixedAccountDay();
        }

        private FixedAccountModel PopulateMetaCemTotalFixedAccountMonth()
        {
            FixedAccountRepository dal = new FixedAccountRepository();
            return dal.GetMetaCemFixedAccountMonth();
        }

        private FixedAccountModel PopulateMetaCemTotalFixedAccountWeek()
        {
            FixedAccountRepository dal = new FixedAccountRepository();
            return dal.GetMetaCemFixedAccountWeek();
        }

        private FixedAccountModel PopulateMetaCemTotalFixedAccountDay()
        {
            FixedAccountRepository dal = new FixedAccountRepository();
            return dal.GetMetaCemFixedAccountDay();
        }

        private FixedAccountModel PopulateMetaCinquentaTotalFixedAccountMonth()
        {
            FixedAccountRepository dal = new FixedAccountRepository();
            return dal.GetMetaCinquentaFixedAccountMonth();
        }

        private FixedAccountModel PopulateMetaCinquentaTotalFixedAccountWeek()
        {
            FixedAccountRepository dal = new FixedAccountRepository();
            return dal.GetMetaCinquentaFixedAccountWeek();
        }

        private FixedAccountModel PopulateMetaCinquentaTotalFixedAccountDay()
        {
            FixedAccountRepository dal = new FixedAccountRepository();
            return dal.GetMetaCinquentaFixedAccountDay();
        }

        #endregion
    }
}
