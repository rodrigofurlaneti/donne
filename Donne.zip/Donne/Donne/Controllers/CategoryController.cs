﻿using Donne.Dal;
using Donne.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

namespace Donne.Controllers
{
    public class CategoryController : Controller
    {
		#region Properties
		private readonly ILogger<CategoryController> _logger;
        #endregion
        #region Constructors
        public CategoryController(ILogger<CategoryController> logger)
        {
            _logger = logger;
        }
		#endregion
		#region Actions
		public IActionResult Index()
        {
            IEnumerable<CategoryModel> listCategoryModels = PopulateCategory();
            return View(listCategoryModels);
        }
        public IActionResult Insert()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Insert(CategoryModel categoryModel)
        {
            CategoryRepository dal = new CategoryRepository();
            dal.Insert(categoryModel);
            ViewBag.Message = String.Format("Cadastrado uma nova categoria com sucesso!");
            return View();
        }

        [HttpGet]
        public IActionResult Update(int id)
        {
            CategoryRepository dal = new CategoryRepository();
            CategoryModel categoryModel = dal.GetById(id);
            return View(categoryModel);
        }

        [HttpPost]
        public IActionResult Update(CategoryModel categoryModel)
        {
            CategoryRepository dal = new CategoryRepository();
            dal.Update(categoryModel);
            ViewBag.Message = String.Format("Atualizado a categoria com sucesso!");
            return View(categoryModel);
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            CategoryRepository dal = new CategoryRepository();
            dal.Delete(id);
            return RedirectToAction("Index","Category");
        }
		#endregion
		#region Methods
        private IEnumerable<CategoryModel> PopulateCategory()
		{
            CategoryRepository dal = new CategoryRepository();
            return dal.GetAllCategories();
        }
		#endregion
	}
}
