﻿using Donne.Dal;
using Donne.Dal.Customer;
using Donne.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

namespace Donne.Controllers
{
    public class CommandController : Controller
    {
        private readonly ILogger<CommandController> _logger;

        public CommandController(ILogger<CommandController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            CommandRepository dal = new CommandRepository();
            IEnumerable<CommandModel> listCommandModels = dal.GetAllCommands();
            foreach (var item in listCommandModels)
            {
                if(item.EndDateAndTime.ToString() == "01/01/1900 00:00:00")
                {
                    item.EndDateAndTime = null;
                }
            }
            return View(listCommandModels);
        }
        public IActionResult Insert()
        {
            var commandModel = new CommandModel();
            commandModel.StartDateAndTime = DateTime.Now;
            CustomerRepository dal = new CustomerRepository();
            IEnumerable<CustomerModel> listCustomerModels = dal.GetAllCustomers();
            ViewBag.CustomerId = listCustomerModels;
            ViewBag.PaidOut = new List<SelectListItem>{ new SelectListItem{ Text="Não", Value = "false" },
                                                        new SelectListItem{ Text="Sim", Value = "true" }};
            return View(commandModel);
        }

        [HttpPost]
        public IActionResult Insert(CommandModel CommandModel)
        {
            CommandRepository dal = new CommandRepository();
            dal.Insert(CommandModel);
            return RedirectToAction("Index", "Command");
        }

        [HttpGet]
        public IActionResult Update(int id)
        {
            CommandRepository dal = new CommandRepository();
            CommandModel commandModel = dal.GetById(id);
            if (commandModel.EndDateAndTime.ToString() == "01/01/1900 00:00:00")
            {
                commandModel.EndDateAndTime = null;
            }
            CustomerRepository dalCustomer = new CustomerRepository();
            IEnumerable<CustomerModel> listCustomerModels = dalCustomer.GetAllCustomers();
            ViewBag.CustomerId = listCustomerModels;
            ViewBag.PaidOut = new List<SelectListItem>{ new SelectListItem{ Text="Não", Value = "false" },
                                                        new SelectListItem{ Text="Sim", Value = "true" }};
            return View(commandModel);
        }

        [HttpPost]
        public IActionResult Update(CommandModel commandModel)
        {
            CommandRepository dal = new CommandRepository();
            if (commandModel.EndDateAndTime == null)
            {
                commandModel.EndDateAndTime = Convert.ToDateTime("01/01/1900 00:00:00");
            }
            dal.Update(commandModel);
            return RedirectToAction("Index", "Command");
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            CommandRepository dal = new CommandRepository();
            dal.Delete(id);
            return RedirectToAction("Index", "Command");
        }
    }
}
