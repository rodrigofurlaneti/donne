﻿using Donne.Dal;
using Donne.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace Donne.Controllers
{
    public class AccountController : Controller
    {
        public IActionResult Index()
        {
            CommandRepository dalCommand = new CommandRepository();
            IEnumerable<CommandModel> listCommandModels = dalCommand.GetAllActiveCommands();
            ViewBag.CommandId = listCommandModels;
            return View();
        }

        [HttpGet]
        public IActionResult Insert(int id)
        {
            AccountRepository dal = new AccountRepository();
            List<AccountModel> accountModel = dal.GetById(id);
            ViewBag.CommandId = accountModel[0].CommandId;
            ViewBag.StartDateAndTime = accountModel[0].StartDateAndTime;
            ViewBag.CustomerName = accountModel[0].CustomerName;
            ViewBag.TotalAccountValue = accountModel[0].TotalAccountValue;
            return View(accountModel);
        }
    }
}
