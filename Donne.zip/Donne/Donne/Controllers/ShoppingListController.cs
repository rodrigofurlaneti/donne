﻿using Donne.Dal;
using Donne.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Donne.Controllers
{
	public class ShoppingListController : Controller
	{
		private readonly ILogger<ShoppingListController> _logger;
		public ShoppingListController(ILogger<ShoppingListController> logger)
		{
			_logger = logger;

		}
		public IActionResult Index()
		{
			ShoppingListRepository dal = new ShoppingListRepository();
			IEnumerable<ShoppingListModel> shoppingListModels = dal.GetAllShoppingList();
			return View(shoppingListModels);
		}
	}
}
