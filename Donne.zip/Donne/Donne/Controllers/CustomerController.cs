﻿using Donne.Dal.Customer;
using Donne.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;

namespace Donne.Controllers
{
    public class CustomerController : Controller
    {
		#region Properties
		private readonly ILogger<CustomerController> _logger;
        #endregion
        #region Constructors
        public CustomerController(ILogger<CustomerController> logger)
        {
            _logger = logger;
        }
		#endregion
		#region Actions
		public IActionResult Index()
        {
            CustomerRepository dal = new CustomerRepository();
            var listCustomerModels = dal.GetAllCustomers();
            return View(listCustomerModels);
        }
        public IActionResult Insert()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Insert(CustomerModel customerModel)
        {
            CustomerRepository dal = new CustomerRepository();
            dal.Insert(customerModel);
            ViewBag.Message = String.Format("Cadastrado um novo cliente com sucesso!");
            return View();
        }

        [HttpGet]
        public IActionResult Update(int id)
        {
            CustomerRepository dal = new CustomerRepository();
            CustomerModel customerModel = dal.GetById(id);
            return View(customerModel);
        }

        [HttpPost]
        public IActionResult Update(CustomerModel customerModel)
        {
            CustomerRepository dal = new CustomerRepository();
            dal.Update(customerModel);
            ViewBag.Message = String.Format("Atualizado o cliente com sucesso!");
            return View(customerModel);
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            CustomerRepository dal = new CustomerRepository();
            dal.Delete(id);
            return RedirectToAction("Index", "Customer");
        }
		#endregion
	}
}
