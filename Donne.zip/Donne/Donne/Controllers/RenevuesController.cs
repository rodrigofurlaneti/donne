﻿using Donne.Dal;
using Donne.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;

namespace Donne.Controllers
{
	public class RenevuesController : Controller
	{
		#region Actions
		public IActionResult Index()
		{
			RevenuesRepository dal = new RevenuesRepository();
			List<RevenuesModel> listRenevuesModels = new List<RevenuesModel>();
			for (int i = 1; i <= 12; i++)
			{
				RevenuesModel renevuesModel = dal.GetAllRevenues(i);
				if (renevuesModel != null)
				{
					RevenuesModel revenues = new RevenuesModel();
					revenues.MonthNumber = i;
					revenues.MonthName = MonthName(i);
					revenues.Amount = renevuesModel.Amount;
					listRenevuesModels.Add(revenues);
				}
			}
			return View(listRenevuesModels);
		}
		[HttpGet]
		public IActionResult IndexJson()
		{
			RevenuesRepository dal = new RevenuesRepository();
			List<RevenuesModel> listRenevuesModels = new List<RevenuesModel>();
			for (int i = 1; i <= 12; i++)
			{
				RevenuesModel renevuesModel = dal.GetAllRevenues(i);
				if (renevuesModel != null)
				{
					RevenuesModel revenues = new RevenuesModel();
					revenues.MonthNumber = i;
					revenues.MonthName = MonthName(i);
					revenues.Amount = renevuesModel.Amount;
					listRenevuesModels.Add(revenues);
				}
			}
			return Json(listRenevuesModels);
		}

		#endregion
		#region Methods
		private string MonthName(int number)
		{
			switch (number)
			{
				case 1:
					return "Janeiro";
					break;
				case 2:
					return "Fevereiro";
					break;
				case 3:
					return "Março";
					break;
				case 4:
					return "Abril";
					break;
				case 5:
					return "Maio";
					break;
				case 6:
					return "Junho";
					break;
				case 7:
					return "Julho";
					break;
				case 8:
					return "Agosto";
					break;
				case 9:
					return "Setembro";
					break;
				case 10:
					return "Outubro";
					break;
				case 11:
					return "Novembro";
					break;
				case 12:
					return "Dezembro";
					break;
				default:
					return String.Empty;
					break;
			}
		}
		#endregion
	}
}
