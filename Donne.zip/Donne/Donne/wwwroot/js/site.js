﻿function formatarMoedaCostPrice() {
    var elemento = document.getElementById('CostPrice');
    var valor = elemento.value;
    valor = valor + '';
    valor = parseInt(valor.replace(/[\D]+/g, ''));
    valor = valor + '';
    valor = valor.replace(/([0-9]{2})$/g, ",$1");
    if (valor.length > 6) {
        valor = valor.replace(/([0-9]{3}),([0-9]{2}$)/g, ".$1,$2");
    }
    elemento.value = valor;
    if (valor == 'NaN') elemento.value = '';
}

function formatarMoedaSalePrice() {
    var elemento = document.getElementById('SalePrice');
    var valor = elemento.value;
    valor = valor + '';
    valor = parseInt(valor.replace(/[\D]+/g, ''));
    valor = valor + '';
    valor = valor.replace(/([0-9]{2})$/g, ",$1");
    if (valor.length > 6) {
        valor = valor.replace(/([0-9]{3}),([0-9]{2}$)/g, ".$1,$2");
    }
    elemento.value = valor;
    if (valor == 'NaN') elemento.value = '';
}

function calcular() {
    var costPrice = document.querySelector("#CostPrice");
    var salePrice = document.querySelector("#SalePrice");
    var quantityStock = document.querySelector("#QuantityStock");
    var totalValueCostOfInventory = parseFloat(costPrice.value.replace(',', '.')) * parseInt(quantityStock.value);
    var totalValueSaleStock = parseFloat(salePrice.value.replace(',', '.')) * parseInt(quantityStock.value);
    document.getElementById('TotalValueCostOfInventory').value = totalValueCostOfInventory.toLocaleString("pt-BR", {minimumFractionDigits: 2, maximumFractionDigits: 2 });
    document.getElementById('TotalValueSaleStock').value = totalValueSaleStock.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function cont() {
    var conteudo = document.getElementById('print').innerHTML;
    tela_impressao = window.open('about:blank');
    tela_impressao.document.write(conteudo);
    tela_impressao.window.print();
    tela_impressao.window.close();
}

function formatarMoedaFixedAccountMonth() {
    var elemento = document.getElementById('FixedAccountMonth');
    var valor = elemento.value;
    valor = valor + '';
    valor = parseInt(valor.replace(/[\D]+/g, ''));
    valor = valor + '';
    valor = valor.replace(/([0-9]{2})$/g, ",$1");
    if (valor.length > 6) {
        valor = valor.replace(/([0-9]{3}),([0-9]{2}$)/g, ".$1,$2");
    }
    elemento.value = valor;
    if (valor == 'NaN') elemento.value = '';
}

function formatarMoedaFixedAccountWeek() {
    var elemento = document.getElementById('FixedAccountWeek');
    var valor = elemento.value;
    valor = valor + '';
    valor = parseInt(valor.replace(/[\D]+/g, ''));
    valor = valor + '';
    valor = valor.replace(/([0-9]{2})$/g, ",$1");
    if (valor.length > 6) {
        valor = valor.replace(/([0-9]{3}),([0-9]{2}$)/g, ".$1,$2");
    }
    elemento.value = valor;
    if (valor == 'NaN') elemento.value = '';
}

function formatarMoedaFixedAccountDay() {
    var elemento = document.getElementById('FixedAccountDay');
    var valor = elemento.value;
    valor = valor + '';
    valor = parseInt(valor.replace(/[\D]+/g, ''));
    valor = valor + '';
    valor = valor.replace(/([0-9]{2})$/g, ",$1");
    if (valor.length > 6) {
        valor = valor.replace(/([0-9]{3}),([0-9]{2}$)/g, ".$1,$2");
    }
    elemento.value = valor;
    if (valor == 'NaN') elemento.value = '';
}

function calcularFixedAccount() {
    var fixedAccountMonth = document.querySelector("#FixedAccountMonth");
    var totalValueWeek = parseFloat(fixedAccountMonth.value.replace(',', '.')) / 4;
    var totalValueDay = parseFloat(fixedAccountMonth.value.replace(',', '.')) / 30;
    document.getElementById('FixedAccountWeek').value = totalValueWeek.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    document.getElementById('FixedAccountDay').value = totalValueDay.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}


function formatarMoedaOutOfCashValue() {
    var elemento = document.getElementById('OutOfCashValue');
    var valor = elemento.value;
    valor = valor + '';
    valor = parseInt(valor.replace(/[\D]+/g, ''));
    valor = valor + '';
    valor = valor.replace(/([0-9]{2})$/g, ",$1");
    if (valor.length > 6) {
        valor = valor.replace(/([0-9]{3}),([0-9]{2}$)/g, ".$1,$2");
    }
    elemento.value = valor;
    if (valor == 'NaN') elemento.value = '';
}
/*!
* Start Bootstrap - Simple Sidebar v6.0.3 (https://startbootstrap.com/template/simple-sidebar)
* Copyright 2013-2021 Start Bootstrap
* Licensed under MIT (https://github.com/StartBootstrap/startbootstrap-simple-sidebar/blob/master/LICENSE)
*/
// 
// Scripts
// 

window.addEventListener('DOMContentLoaded', event => {

    // Toggle the side navigation
    const sidebarToggle = document.body.querySelector('#sidebarToggle');
    if (sidebarToggle) {
        // Uncomment Below to persist sidebar toggle between refreshes
        // if (localStorage.getItem('sb|sidebar-toggle') === 'true') {
        //     document.body.classList.toggle('sb-sidenav-toggled');
        // }
        sidebarToggle.addEventListener('click', event => {
            event.preventDefault();
            document.body.classList.toggle('sb-sidenav-toggled');
            localStorage.setItem('sb|sidebar-toggle', document.body.classList.contains('sb-sidenav-toggled'));
        });
    }

});
